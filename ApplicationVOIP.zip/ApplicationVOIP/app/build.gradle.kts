
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    id("com.google.gms.google-services")
    alias(libs.plugins.google.android.libraries.mapsplatform.secrets.gradle.plugin)

}

android {
    namespace = "com.example.application"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.application"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
    buildFeatures {
        compose = true
    }
}


dependencies {

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.play.services.maps)
    implementation(libs.androidx.legacy.support.v4)
    implementation(libs.androidx.lifecycle.livedata.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.ktx)
    implementation(libs.androidx.fragment.ktx)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.ui.test.junit4)
    debugImplementation(libs.androidx.ui.tooling)
    debugImplementation(libs.androidx.ui.test.manifest)
    implementation(platform("com.google.firebase:firebase-bom:33.4.0"))
    implementation("com.google.firebase:firebase-auth")
    // Import the BoM for the Firebase platform
    implementation(platform("com.google.firebase:firebase-bom:33.5.1"))
    // Add the dependency for the Realtime Database library
    // When using the BoM, you don't specify versions in Firebase library dependencies
    implementation("com.google.firebase:firebase-database")

    // for adding recyclerview
    implementation ("androidx.recyclerview:recyclerview:1.3.2")

    // for adding cardview
    implementation ("androidx.cardview:cardview:1.0.0")
    //implementation ("com.google.android.material:material:1.6.0")
    implementation ("com.github.bumptech.glide:glide:4.15.1")// ADDED THIS TO IMPORT GLIDE FOR IMAGE IN READING
    annotationProcessor ("com.github.bumptech.glide:compiler:4.15.1") //ADDED THIS TO IMPORT GLIDE FOR IMAGE READING
    implementation("com.google.android.material:material:1.9.0") //ADD THIS FOR FRAGMENT_MEDICATION.XML
    implementation ("androidx.lifecycle:lifecycle-viewmodel-ktx:2.6.1") //ADD THIS FOR viewModels()
    implementation ("androidx.fragment:fragment-ktx:1.6.1")
    //implementation ("org.webrtc:google-webrtc:1.0.32006")
    //implementation ("com.github.pion:webrtc-android:1.0.32006")
    //implementation ("org.webrtc:google-webrtc:1.0.32006")
    //implementation(libs.google.webrtc)
    implementation ("androidx.core:core-ktx:1.10.1")

}