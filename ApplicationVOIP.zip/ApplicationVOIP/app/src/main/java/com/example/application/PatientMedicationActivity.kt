package com.example.application

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class PatientMedicationActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_patient_medication)
        if (savedInstanceState == null) {
            val fragment = PatientMedicationsFragment()
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, fragment) // Use a container to place the fragment
                .commit()
        }
        val Cart: ImageButton=findViewById(R.id.cartmeds)
        Cart.setOnClickListener(){
            var IntentCart=Intent(this,CartActivity::class.java)
            startActivity(IntentCart)
        }

    }
}