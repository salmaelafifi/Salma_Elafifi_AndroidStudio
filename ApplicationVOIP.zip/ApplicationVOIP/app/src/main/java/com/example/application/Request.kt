package com.example.application

data class Request (

    val medicationName: String="",
    val clientId: String="",
    var key:String=""



)