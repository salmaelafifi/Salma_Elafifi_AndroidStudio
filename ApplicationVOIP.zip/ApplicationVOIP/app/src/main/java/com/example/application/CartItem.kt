package com.example.application

data class CartItem(
    //var medicationId:String="",
    var name: String = "",
    val price: Double = 0.0,
    var quantity: Long = 0
)