package com.example.application

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener

class HomePagePatient : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference
    private lateinit var greetingText: TextView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home_page_patient)

        auth = Firebase.auth
        database = FirebaseDatabase.getInstance().reference

        greetingText = findViewById(R.id.greetingText)

        // Get the current user data from Firebase
        val currentUser = auth.currentUser
        val uid = currentUser?.uid

        if (uid != null) {
            // Listen for changes in the user's data
            database.child("users").child(uid).addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        val username = snapshot.child("username").value?.toString() ?: "User"
                        greetingText.text = "Hello, $username"
                    } else {
                        greetingText.text = "Hello, User"
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    // Handle database error
                    Toast.makeText(
                        this@HomePagePatient,
                        "Failed to fetch username: ${error.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        } else {
            greetingText.text = "Hello, User"
        }

        // Set up navigation buttons
        val profileButton: ImageButton = findViewById(R.id.profile)
        profileButton.setOnClickListener {
            val intentProfile = Intent(this, Profile::class.java)
            startActivity(intentProfile)
        }

        val medicationButton: ImageButton = findViewById(R.id.medication)
        medicationButton.setOnClickListener {
            val intentMedications = Intent(this, PatientMedicationActivity::class.java)
            startActivity(intentMedications)
        }

        val cartButton: ImageButton = findViewById(R.id.cart)
        cartButton.setOnClickListener {
            val intentCart = Intent(this, CartActivity::class.java)
            startActivity(intentCart)
        }

        val requestsButton: ImageButton = findViewById(R.id.requests)
        requestsButton.setOnClickListener {
            val intentRequests = Intent(this, PatientRequestsActivity::class.java)
            startActivity(intentRequests)
        }
        val voipCallButton: ImageButton = findViewById(R.id.voipCallButton)
        voipCallButton.setOnClickListener {
            val intentCall=Intent(this, VoIPActivity::class.java)
            startActivity(intentCall)

        }

        val mapButton: ImageButton = findViewById(R.id.map)
        mapButton.setOnClickListener {
            val intentMap = Intent(this, MapsActivity::class.java)
            startActivity(intentMap)
        }
    }
}