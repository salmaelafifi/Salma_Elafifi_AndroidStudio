package com.example.application

import android.util.Log
import java.io.IOException
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors

class CallListener(
    private val port: Int,
    private val onIncomingCall: (Socket) -> Unit,
    private val onError: (Exception) -> Unit
) {
    var isListening = false
        private set
    private val executor = Executors.newSingleThreadExecutor()
    private var serverSocket: ServerSocket? = null

    fun startListening() {
        if (isListening) return
        isListening = true
        executor.execute {
            try {
                serverSocket = ServerSocket(port).apply {
                    reuseAddress = true
                }
                Log.d("CallListener", "Listening for calls on port $port")
                while (isListening) {
                    val clientSocket = serverSocket!!.accept()
                    onIncomingCall(clientSocket)
                }
            } catch (e: IOException) {
                if (isListening) {
                    Log.e("CallListener", "Error in server socket", e)
                    onError(e)
                }
            }
        }
    }

    fun stopListening() {
        if (!isListening) return
        isListening = false
        try {
            serverSocket?.close()
            Log.d("CallListener", "ServerSocket closed")
        } catch (e: IOException) {
            Log.e("CallListener", "Error closing ServerSocket", e)
        }
        executor.shutdown()
    }
}
