package com.example.application

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class PatientRequestsFragment : Fragment() {
    private lateinit var requestsRecyclerView: RecyclerView
    private lateinit var requestConsultationButton: Button
    private lateinit var requestsAdapter: RequestsAdapter
    private val requestsList = ArrayList<RequestsItem>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_patient_requests, container, false)
        requestsRecyclerView = view.findViewById(R.id.requestsRecyclerView)
        requestConsultationButton = view.findViewById(R.id.requestConsultationButton)

        requestsAdapter = RequestsAdapter(requestsList)
        requestsRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        requestsRecyclerView.adapter = requestsAdapter

        fetchRequests()

        requestConsultationButton.setOnClickListener {
            showConsultationDialog()
        }

        return view
    }

    private fun fetchRequests() {
        val currentUser = FirebaseAuth.getInstance().currentUser
        val userId = currentUser?.uid

        if (userId != null) {
            val userRequestsRef = FirebaseDatabase.getInstance().getReference("users").child(userId).child("requests")

            userRequestsRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    requestsList.clear()
                    snapshot.child("approvals").children.forEach { approval ->
                        val approvalKey = approval.key ?: return@forEach
                        val medicationName = approval.child("medicationName").getValue(String::class.java) ?: "Unknown Medication"
                        val status = approval.child("status").getValue(String::class.java) ?: "Unknown"
                        requestsList.add(RequestsItem(medicationName, status, "Approval"))
                    }

                    snapshot.child("consultations").children.forEach { consultation ->
                        val consultationKey = consultation.key ?: return
                        val question = consultation.child("question").getValue(String::class.java) ?: "Unknown Question"
                        val answer = consultation.child("answer").getValue(String::class.java) ?: "No Answer Yet"
                        requestsList.add(RequestsItem(question, answer, "Consultation"))
                    }
                    requestsAdapter.notifyDataSetChanged()
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(requireContext(), "Error fetching requests", Toast.LENGTH_SHORT).show()
                }
            })
        }
    }

    private fun showConsultationDialog() {
        val dialog = AlertDialog.Builder(requireContext())
        dialog.setTitle("New Consultation")
        val input = EditText(requireContext())
        dialog.setView(input)

        dialog.setPositiveButton("Save") { _, _ ->
            val question = input.text.toString().trim()
            if (question.isNotEmpty()) {
                val currentUser = FirebaseAuth.getInstance().currentUser
                val userId = currentUser?.uid

                if (userId != null) {
                    val consultationsRef = FirebaseDatabase.getInstance().reference.child("Consultations")
                    val userRequestsRef = FirebaseDatabase.getInstance().getReference("users")
                        .child(userId)
                        .child("requests")
                        .child("consultations")

                    // Generate a unique key for the consultation
                    val consultationKey = consultationsRef.push().key

                    if (consultationKey != null) {
                        val requestDataGlobal = mapOf(
                            "question" to question,
                            "clientID" to userId
                        )
                        val requestDataUser = mapOf(
                            "question" to question,
                            "answer" to "" // Placeholder for the answer
                        )

                        // Save consultation to the global Consultations node
                        consultationsRef.child(consultationKey).setValue(requestDataGlobal)
                            .addOnSuccessListener {
                                Log.d("ConsultationDialog", "Global consultation saved successfully.")
                            }
                            .addOnFailureListener { error ->
                                Log.e("ConsultationDialog", "Failed to save global consultation: ${error.message}")
                            }

                        // Save consultation to the user-specific consultations node
                        userRequestsRef.child(consultationKey).setValue(requestDataUser)
                            .addOnSuccessListener {
                                Log.d("ConsultationDialog", "User consultation saved successfully.")
                            }
                            .addOnFailureListener { error ->
                                Log.e("ConsultationDialog", "Failed to save user consultation: ${error.message}")
                            }

                        Toast.makeText(requireContext(), "Consultation submitted", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(requireContext(), "Failed to generate unique consultation ID", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(requireContext(), "User not authenticated", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(requireContext(), "Please enter a valid question", Toast.LENGTH_SHORT).show()
            }
        }
        dialog.setNegativeButton("Cancel", null)
        dialog.show()
    }
}