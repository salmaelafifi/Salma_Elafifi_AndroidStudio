package com.example.application

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class Register : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register)

        auth = Firebase.auth
        database = FirebaseDatabase.getInstance().reference

        val emailInput: TextInputEditText = findViewById(R.id.EmailR)
        val passwordInput: TextInputEditText = findViewById(R.id.PasswordR)
        val usernameInput: TextInputEditText = findViewById(R.id.username)
        val radioGroupGender: RadioGroup = findViewById(R.id.rgGender)
        val radioGroupUsertype: RadioGroup = findViewById(R.id.rgUserType)
        val registerButton: Button = findViewById(R.id.buttonRegister)

        registerButton.setOnClickListener {
            val userEmail = emailInput.text.toString()
            val userPassword = passwordInput.text.toString()
            val username = usernameInput.text.toString()
            val selectedGenderId = radioGroupGender.checkedRadioButtonId
            val selectedUserId = radioGroupUsertype.checkedRadioButtonId
            val gender = findViewById<RadioButton>(selectedGenderId)?.text.toString()
            val userType = findViewById<RadioButton>(selectedUserId)?.text.toString()

            if (userEmail.isNotEmpty() && userPassword.isNotEmpty() && username.isNotEmpty() && gender.isNotEmpty() && userType.isNotEmpty()) {
                auth.createUserWithEmailAndPassword(userEmail, userPassword).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val currentUser = auth.currentUser
                        val uid = currentUser?.uid

                        val userMap = mapOf(
                            "username" to username,
                            "email" to userEmail,
                            "password" to userPassword,
                            "gender" to gender,
                            "userType" to userType
                        )

                        if (uid != null) {
                            database.child("users").child(uid).setValue(userMap).addOnSuccessListener {
                                // Navigate to the appropriate home page based on user type
                                if (userType == "Doctor") {
                                    startActivity(Intent(this, HomePageDoctor::class.java))
                                } else {
                                    startActivity(Intent(this, HomePagePatient::class.java))
                                }
                                finish()
                            }.addOnFailureListener {
                                Toast.makeText(this, "Failed to save user data", Toast.LENGTH_SHORT).show()
                            }
                        }
                    } else {
                        val errorMessage = task.exception?.message ?: "Unknown error"
                        Toast.makeText(this, "Registration Failed: $errorMessage", Toast.LENGTH_LONG).show()
                    }
                }
            } else {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            }
        }
    }
}







