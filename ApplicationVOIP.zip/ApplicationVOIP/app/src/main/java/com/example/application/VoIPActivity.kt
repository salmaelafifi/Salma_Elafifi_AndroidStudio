package com.example.application

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.net.Socket
import java.util.concurrent.Executors

class VoIPActivity : AppCompatActivity() {
    private lateinit var statusTextView: TextView
    private lateinit var ipAddressEditText: EditText
    private lateinit var portEditText: EditText
    private lateinit var callDoctorButton: Button
    private val executor = Executors.newSingleThreadExecutor()
    private var audioStreamingThread: Thread? = null
    private var isStreaming = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.vo_ipactivity)

        statusTextView = findViewById(R.id.statusTextView)
        ipAddressEditText = findViewById(R.id.ipAddressEditText)
        portEditText = findViewById(R.id.portEditText)
        callDoctorButton = findViewById(R.id.callDoctorButton)
        val endCallButton: Button = findViewById(R.id.endCallButton)

        // Show End Call button when call starts
        endCallButton.setOnClickListener {
            stopAudioStreaming() // Stop audio streaming
            Toast.makeText(this, "Call ended", Toast.LENGTH_SHORT).show()
            endCallButton.visibility = View.GONE // Hide the button
        }

        // Check for audio permission
        if (!hasAudioPermission()) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }

        // Patient initiates a call
        callDoctorButton.setOnClickListener {
            val ipAddress = ipAddressEditText.text.toString()
            val port = portEditText.text.toString().toIntOrNull()

            if (ipAddress.isBlank() || port == null) {
                Toast.makeText(this, "Please enter a valid IP address and port.", Toast.LENGTH_SHORT).show()
            } else {
                initiateCallToDoctor(ipAddress, port)
            }
        }
    }

    private fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    }

    private fun initiateCallToDoctor(ipAddress: String, port: Int) {
        executor.execute {
            try {
                Log.d("VoIPActivity", "Attempting to connect to $ipAddress:$port")
                val socket = Socket(ipAddress, port)
                Log.d("VoIPActivity", "Connected to $ipAddress:$port")
                isStreaming = true
                startAudioStreaming(socket) // Start audio streaming

                runOnUiThread {
                    statusTextView.text = "Connected to Doctor at $ipAddress:$port"
                    Toast.makeText(this, "Call initiated!", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e("VoIPActivity", "Connection failed", e)
                runOnUiThread {
                    statusTextView.text = "Failed to connect to Doctor."
                    Toast.makeText(this, "Call failed: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun startAudioStreaming(socket: Socket) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Log.e("VoIPActivity", "Permission to record audio not granted")
            return
        }
        audioStreamingThread = Thread {
            try {
                val minBufferSize = AudioRecord.getMinBufferSize(
                    44100,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )

                val audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    44100,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    minBufferSize
                )

                val audioTrack = AudioTrack(
                    AudioManager.STREAM_VOICE_CALL,
                    44100,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    minBufferSize,
                    AudioTrack.MODE_STREAM
                )

                if (AcousticEchoCanceler.isAvailable()) {
                    val echoCanceler = AcousticEchoCanceler.create(audioRecord.audioSessionId)
                    echoCanceler.enabled = true
                }

                if (NoiseSuppressor.isAvailable()) {
                    val noiseSuppressor = NoiseSuppressor.create(audioRecord.audioSessionId)
                    noiseSuppressor.enabled = true
                }

                audioRecord.startRecording()
                audioTrack.play()

                val outputStream = socket.getOutputStream()
                val inputStream = socket.getInputStream()

                val sendBuffer = ByteArray(minBufferSize)
                val receiveBuffer = ByteArray(minBufferSize)

                while (!Thread.interrupted()) {
                    // Capture and send audio
                    val bytesRead = audioRecord.read(sendBuffer, 0, sendBuffer.size)
                    if (bytesRead > 0) {
                        outputStream.write(sendBuffer, 0, bytesRead)
                    }

                    // Receive and play audio
                    val bytesReceived = inputStream.read(receiveBuffer)
                    if (bytesReceived > 0) {
                        audioTrack.write(receiveBuffer, 0, bytesReceived)
                    }
                }

                audioRecord.stop()
                audioRecord.release()
                audioTrack.stop()
                audioTrack.release()
                socket.close()
            } catch (e: Exception) {
                Log.e("VoIPActivity", "Error in enhanced audio streaming", e)
            }
        }
        audioStreamingThread?.start()
    }
    private fun stopAudioStreaming() {
        isStreaming = false
        audioStreamingThread?.interrupt()
        audioStreamingThread = null
    }

    override fun onDestroy() {
        super.onDestroy()
        stopAudioStreaming()
        executor.shutdown()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission granted", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Permission denied. Cannot start call.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
