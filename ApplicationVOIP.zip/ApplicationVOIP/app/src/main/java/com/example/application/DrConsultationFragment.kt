package com.example.application

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class DrConsultationFragment : Fragment() {
    private lateinit var viewModel: DrConsultationViewModel
    private lateinit var adapter: DrConsultationAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.consultation_fragment, container, false)

        // Initialize RecyclerView
        val recyclerView = view.findViewById<RecyclerView>(R.id.consultationsRecyclerView)
        adapter = DrConsultationAdapter { consultation, answer ->
            // Handle the answer submission
            if (consultation.key.isNotEmpty()) {
                viewModel.answerConsultation(consultation, answer)
            } else {
                Toast.makeText(
                    requireContext(),
                    "Consultation key missing. Cannot submit answer.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = adapter

        // Initialize ViewModel
        viewModel = ViewModelProvider(this).get(DrConsultationViewModel::class.java)

        // Observe LiveData
        viewModel.consultations.observe(viewLifecycleOwner) { consultations ->
            adapter.submitList(consultations)
        }

        // Fetch consultations
        viewModel.fetchConsultations()

        return view
    }
}