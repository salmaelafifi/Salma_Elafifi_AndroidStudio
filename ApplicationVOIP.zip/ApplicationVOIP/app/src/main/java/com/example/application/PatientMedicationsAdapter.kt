package com.example.application

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import android.view.LayoutInflater
import  androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase


class PatientMedicationsAdapter(private val medicationsList: ArrayList<PatientMedication>) :
    RecyclerView.Adapter<PatientMedicationsAdapter.MedicationsViewHolder>() {
    private var expandedPosition = -1
    private val database = FirebaseDatabase.getInstance().getReference("medications")


    inner class MedicationsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val name: TextView = itemView.findViewById(R.id.medicationName)

        var image: ImageView = itemView.findViewById(R.id.medicationImage)
        val description: TextView = itemView.findViewById(R.id.medicationDescription)
        val price: TextView = itemView.findViewById(R.id.medicationPrice)
        val addToCartButton: Button = itemView.findViewById(R.id.addToCartButton)
        val detailsLayout: LinearLayout = itemView.findViewById(R.id.detailsLayout)
        val approvalButton: Button = itemView.findViewById(R.id.approvalButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MedicationsViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_patient_medication, parent, false)
        return MedicationsViewHolder(view)
    }

    override fun onBindViewHolder(holder: MedicationsViewHolder, position: Int) {
        val medication = medicationsList[position]
        holder.name.text = medication.name
        holder.price.text = "$${medication.Price}"
        holder.description.text = medication.Description

        //holder.image=fetchMedicationImage(medication.id )
        medication.id?.let { medicationId ->
            fetchMedicationImage(medicationId) { bitmap ->
                if (bitmap != null) {
                    holder.image.setImageBitmap(bitmap) // Set the fetched Bitmap to the ImageView
                } else {
                    // Set a placeholder image in case the fetch fails
                    holder.image.setImageResource(R.drawable.pillsplaceholder)
                }
            }
        }



        // Toggle the details visibility based on expansion
        val isExpanded = position == expandedPosition
        holder.detailsLayout.visibility = if (isExpanded) View.VISIBLE else View.GONE

        // Toggle the visibility of approval and add to cart buttons
        if (medication.approval) {
            holder.approvalButton.visibility = View.VISIBLE
            holder.addToCartButton.visibility = View.GONE
        } else {
            holder.approvalButton.visibility = View.GONE
            holder.addToCartButton.visibility = View.VISIBLE
        }

        // Add a click listener to the entire item for expansion
        holder.itemView.setOnClickListener {
            expandedPosition = if (isExpanded) -1 else position
            notifyDataSetChanged() // Notify RecyclerView to redraw items
        }

        // Handle the approval button click
        holder.approvalButton.setOnClickListener {
            val medication = medicationsList[position]
            val currentUser = FirebaseAuth.getInstance().currentUser
            val clientId = currentUser?.uid

            if (clientId != null) {
                val approvalsRef = FirebaseDatabase.getInstance().getReference("Approvals")
                val userRequestsRef = FirebaseDatabase.getInstance()
                    .getReference("users")
                    .child(clientId)
                    .child("requests")
                    .child("approvals")

                // Generate a unique key for the approval request
                val approvalKey = approvalsRef.push().key

                if (approvalKey != null) {
                    // Prepare request data
                    val requestData = mapOf(
                        "medicationName" to medication.name,
                        "status" to "Pending",
                        "clientId" to clientId
                    )

                    // Add request to the global Approvals node
                    approvalsRef.child(approvalKey).setValue(requestData)
                        .addOnSuccessListener {
                            // Add request to the user's specific Approvals node
                            userRequestsRef.child(approvalKey).setValue(requestData)
                                .addOnSuccessListener {
                                    Toast.makeText(
                                        holder.itemView.context,
                                        "Approval requested for ${medication.name}",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                                .addOnFailureListener { error ->
                                    Toast.makeText(
                                        holder.itemView.context,
                                        "Failed to add request to user-specific node: ${error.message}",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                        }
                        .addOnFailureListener { error ->
                            Toast.makeText(
                                holder.itemView.context,
                                "Failed to add request to global node: ${error.message}",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                } else {
                    Toast.makeText(holder.itemView.context, "Failed to generate unique approval key", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(holder.itemView.context, "User not authenticated", Toast.LENGTH_SHORT).show()
            }
        }

        // Handle the add to cart button click
        holder.addToCartButton.setOnClickListener {
            val medication = medicationsList[position]
            val currentUser = FirebaseAuth.getInstance().currentUser
            val userId = currentUser?.uid

            if (userId != null) {
                val cartRef = FirebaseDatabase.getInstance().getReference("users").child(userId).child("cart")
                cartRef.child(medication.name).get().addOnSuccessListener { snapshot ->
                    if (snapshot.exists()) {
                        // If the medication is already in the cart, update the quantity
                        val existingQuantity = snapshot.child("quantity").getValue(Int::class.java) ?: 0
                        cartRef.child(medication.name).child("quantity").setValue(existingQuantity + 1)
                    } else {
                        // If it's a new medication, add it to the cart with quantity 1
                        val medicationMap = mapOf(
                            "quantity" to 1,
                            "price" to medication.Price
                        )
                        cartRef.child(medication.name).setValue(medicationMap)
                    }
                    Toast.makeText(holder.itemView.context, "${medication.name} added to cart", Toast.LENGTH_SHORT).show()
                }
            }
        }

    }
    fun fetchMedicationImage(medicationId: String, onComplete: (Bitmap?) -> Unit) {
        // Access the Firebase database reference for medications
        val medicationRef = FirebaseDatabase.getInstance().getReference("medications").child(medicationId)

        medicationRef.child("imageBase64").get().addOnSuccessListener { snapshot ->
            // Check if the snapshot contains the 'imageBase64' field
            val base64Image = snapshot.getValue(String::class.java)

            // Decode the Base64 string to Bitmap
            val bitmap = base64Image?.let { ImageUtilities.decodeBase64ToBitmap(it) }

            // Return the decoded Bitmap via the callback
            onComplete(bitmap)
        }.addOnFailureListener { exception ->
            // Handle failure (e.g., if the image fetching fails)
            Log.e("fetchMedicationImage", "Error fetching medication image: ${exception.message}")
            onComplete(null)  // Return null if there is an error
        }
    }


    fun displayImage(base64Image: String, imageView: ImageView) {
        try {
            val decodedString: ByteArray = Base64.decode(base64Image, Base64.DEFAULT)
            val decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size)
            imageView.setImageBitmap(decodedByte)
        } catch (e: Exception) {
            e.printStackTrace()
            // Handle error
        }
    }


    override fun getItemCount(): Int = medicationsList.size
}





