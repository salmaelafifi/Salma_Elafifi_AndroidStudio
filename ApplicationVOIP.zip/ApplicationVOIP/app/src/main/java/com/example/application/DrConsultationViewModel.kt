package com.example.application

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class DrConsultationViewModel : ViewModel() {
    private val database = FirebaseDatabase.getInstance().getReference("Consultations")
    private val _consultations = MutableLiveData<List<Consultation>>()
    val consultations: LiveData<List<Consultation>> get() = _consultations

    // Fetch consultations
    fun fetchConsultations() {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val consultationList = mutableListOf<Consultation>()
                for (consultationSnapshot in snapshot.children) {
                    val consultation = consultationSnapshot.getValue(Consultation::class.java)?.apply {
                        key =
                            consultationSnapshot.key.toString() // Attach the key to the Consultation object
                    }
                    consultation?.let { consultationList.add(it) }
                }
                _consultations.value = consultationList
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("ConsultationViewModel", "Error fetching consultations: ${error.message}")
            }
        })
    }

    // Mark consultation as answered
    fun answerConsultation(consultation: Consultation, responseText: String) {
        Log.d(
            "DrConsultationViewModel",
            "Processing consultation: ${consultation.question}, answer: $responseText"
        )

        // Reference to the global Consultations node
        val globalConsultationsRef = FirebaseDatabase.getInstance()
            .getReference("Consultations")
            .child(consultation.key!!) // Use the consultation key to directly access the node

        globalConsultationsRef.get().addOnSuccessListener { globalSnapshot ->
            if (globalSnapshot.exists()) {
                Log.d("DrConsultationViewModel", "Found consultation with key: ${consultation.key}")

                // Retrieve the clientId from the global snapshot
                val clientId = globalSnapshot.child("clientID").getValue(String::class.java)

                if (clientId != null) {
                    // Correct path to the user's consultations node
                    val userConsultationsRef = FirebaseDatabase.getInstance()
                        .getReference("users")
                        .child(clientId)
                        .child("requests")
                        .child("consultations")
                        .child(consultation.key!!)

                    // Update the answer field in the user's consultations node
                    userConsultationsRef.child("answer").setValue(responseText)
                        .addOnSuccessListener {
                            Log.d(
                                "DrConsultationViewModel",
                                "Answer saved successfully in user's node for question: ${consultation.question}"
                            )

                            // Remove the consultation from the global Consultations node
                            globalSnapshot.ref.removeValue()
                                .addOnSuccessListener {
                                    Log.d(
                                        "DrConsultationViewModel",
                                        "Consultation removed from global node"
                                    )
                                    // Update LiveData after removal
                                    _consultations.value = _consultations.value?.filterNot {
                                        it.key == consultation.key
                                    }
                                }
                                .addOnFailureListener { error ->
                                    Log.e(
                                        "DrConsultationViewModel",
                                        "Error removing consultation from global node: ${error.message}"
                                    )
                                }
                        }
                        .addOnFailureListener { error ->
                            Log.e(
                                "DrConsultationViewModel",
                                "Error saving answer in user's node: ${error.message}"
                            )
                        }
                } else {
                    Log.e("DrConsultationViewModel", "Client ID not found for consultation key: ${consultation.key}")
                }
            } else {
                Log.e("DrConsultationViewModel", "Consultation not found in global node for key: ${consultation.key}")
            }
        }.addOnFailureListener { error ->
            Log.e(
                "DrConsultationViewModel",
                "Error querying global Consultations node: ${error.message}"
            )
        }
    }

}
