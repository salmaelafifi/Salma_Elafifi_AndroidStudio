package com.example.application

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.ContactsContract.CommonDataKinds.Im
import android.provider.MediaStore
import android.util.Base64
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.application.ImageUtilities.decodeBase64ToBitmap
import com.google.android.material.floatingactionbutton.FloatingActionButton
class MedicationFragment : Fragment() {
    private lateinit var medicationsList: MutableList<Medication> // List to hold medication items
    private lateinit var recyclerView: RecyclerView
    private lateinit var medicationAdapter: MedicationAdapter
    private lateinit var viewModel: MedicationViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_medication, container, false)

        // Initialize RecyclerView
        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        medicationsList = mutableListOf() // Initialize medication list

        // Initialize ViewModel
        viewModel = ViewModelProvider(this).get(MedicationViewModel::class.java)

        // Initialize Adapter
        medicationAdapter = MedicationAdapter(
            medicationList = medicationsList,
            viewModel= viewModel,
            onEditClick = { medication -> editMedication(medication) }, // Pass the clicked medication here
            onImageClick = { medication -> updateMedicationImage(medication) }

        )
        recyclerView.adapter = medicationAdapter


        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val newButton: ImageButton = view.findViewById(R.id.addMedicationFab)
        //val editButton: ImageView= view.findViewById(R.id.editButton)

        // Fetch medications from ViewModel and observe changes
        viewModel.medications.observe(viewLifecycleOwner) { fetchedMedications ->
            medicationsList.clear()
            medicationsList.addAll(fetchedMedications)
            medicationAdapter.notifyDataSetChanged()
        }

        viewModel.fetchMedications() // Trigger initial data load

        // Handle Add New Medication button click
        newButton.setOnClickListener {
            showAddMedicationDialog()
        }

    }
    private var dialogView: View? = null

    private fun showAddMedicationDialog() {
        dialogView = LayoutInflater.from(context).inflate(R.layout.add_medication_window, null)
        val dialog = AlertDialog.Builder(context)
            .setView(dialogView)
            .create()

        val nameEditText = dialogView!!.findViewById<EditText>(R.id.addMedicationName)
        val priceEditText = dialogView!!.findViewById<EditText>(R.id.addMedicationPrice)
        val quantityEditText = dialogView!!.findViewById<EditText>(R.id.addMedicationQuantity)
        val saveButton = dialogView!!.findViewById<Button>(R.id.saveMedicationButton)
        val selectImageButton = dialogView!!.findViewById<Button>(R.id.selectImageButton)
        val medicationDescription= dialogView!!.findViewById<EditText>(R.id.MedicationDescription)
        val approvalCheckBox = dialogView!!.findViewById<CheckBox>(R.id.ApprovalCheckBox)

        tempNewMedication = Medication(
            Name = "",
            Price = 0.0,
            Quantity = 0,
            Description = "",
            id = null, // Firebase will generate the ID later
            imageBase64 = null
        )

        // Handle the "Select Image" button click
        selectImageButton.setOnClickListener {
             updateImageForNewMedication()
        }

        saveButton.setOnClickListener {
            val name = nameEditText.text.toString()
            val price = priceEditText.text.toString().toDoubleOrNull() ?: 0.0
            val quantity = quantityEditText.text.toString().toIntOrNull() ?: 0
            val description = medicationDescription.text.toString()

            if (name.isNotBlank()) {
                val newMedication = Medication(
                    Name = name,
                    Price = price,
                    Quantity = quantity,
                    Description = description,
                    id = null // Firebase will handle the ID generation
                )
                newMedication?.let { newMedication ->
                    viewModel.saveMedication(dialogView!!, newMedication) { success ->
                        if (success) {
                            Toast.makeText(
                                context,
                                "Medication added successfully!",
                                Toast.LENGTH_SHORT
                            ).show()
                            dialog.dismiss()
                            dialogView = null // Clear the reference to avoid memory leaks
                        } else {
                            Toast.makeText(context, "Failed to add medication.", Toast.LENGTH_SHORT)
                                .show()
                        }
                    }
                }
            } else {
                Toast.makeText(
                    context,
                    "Please fill in all fields and select an image.",
                    Toast.LENGTH_SHORT
                ).show()
            }

        }

        dialog.show()
    }

    @SuppressLint("MissingInflatedId")
    private fun editMedication(medication: Medication) {
        val dialogView = LayoutInflater.from(context).inflate(R.layout.edit_window_mediaction, null)
        val dialog = AlertDialog.Builder(context)
            .setView(dialogView)
            .create()

        val nameEditText = dialogView.findViewById<EditText>(R.id.editMedicationName)
        val priceEditText = dialogView.findViewById<EditText>(R.id.editMedicationPrice)
        val quantityEditText = dialogView.findViewById<EditText>(R.id.editMedicationQuantity)
        val saveButton = dialogView.findViewById<Button>(R.id.saveButton)
        val medicationDescription = dialogView.findViewById<EditText>(R.id.MedicationDescription)

        nameEditText.setText(medication.Name)
        priceEditText.setText(medication.Price.toString())
        quantityEditText.setText(medication.Quantity.toString())
        medicationDescription.setText(medication.Description)

        saveButton.setOnClickListener {
            val newName = nameEditText.text.toString()
            val newPrice = priceEditText.text.toString().toDoubleOrNull() ?: medication.Price
            val newQuantity = quantityEditText.text.toString().toIntOrNull() ?: medication.Quantity
            val newDescription = medicationDescription.text.toString()

            medication.Name = newName
            medication.Price = newPrice
            medication.Quantity = newQuantity
            medication.Description= newDescription

            viewModel.updateMedication(medication) { success ->
                if (success) {
                    Toast.makeText(context, "Medication updated successfully!", Toast.LENGTH_SHORT)
                        .show()
                } else {
                    Toast.makeText(context, "Failed to update medication.", Toast.LENGTH_SHORT)
                        .show()
                }
            }
            dialog.dismiss()
        }

        dialog.show()
    }


    private fun updateMedicationImage(medication: Medication) {

        // Inflate the custom dialog view
        val dialogView = LayoutInflater.from(context).inflate(R.layout.edit_image_window, null)
        val dialog = AlertDialog.Builder(requireContext())
            .setView(dialogView)
            .create()

        // Find buttons in the dialog
        val uploadButton = dialogView.findViewById<Button>(R.id.uploadButton)
        val takePhotoButton = dialogView.findViewById<Button>(R.id.takePhotoButton)
        val cancelButton = dialogView.findViewById<Button>(R.id.cancelButton)

        // Handle the "Upload from Gallery" action
        uploadButton.setOnClickListener {
            openGalleryForImage(medication) // Open gallery for the clicked medication
            dialog.dismiss()
        }

        // Handle the "Take Photo" action
        takePhotoButton.setOnClickListener {
            requestCameraPermission(medication) // Open camera for the clicked medication
            dialog.dismiss()
        }

        // Handle the "Cancel" action
        cancelButton.setOnClickListener {
            dialog.dismiss()
        }

        // Show the dialog
        dialog.show()


    }


    private val GALLERY_REQUEST_CODE = 1001
    private val CAMERA_REQUEST_CODE = 1002
    private var currentMedicationId: String? = ""

    private fun openGalleryForImage(medication: Medication) {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, GALLERY_REQUEST_CODE)
        currentMedicationId = medication.id
    }


    private val CAMERA_PERMISSION_REQUEST_CODE = 2001


    // Check if the app has camera permission
    private fun hasCameraPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            requireContext(),
            android.Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
    }

    // Request camera permission
    private fun requestCameraPermission(medication: Medication) {
        if (!hasCameraPermission()) {
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(android.Manifest.permission.CAMERA),
                CAMERA_PERMISSION_REQUEST_CODE
            )
        } else {
            takePhotoForImage(medication) // Proceed to take photo if permission is granted
        }
    }

    fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
        medication: Medication
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, now take the photo
                takePhotoForImage(medication )
            } else {
                // Permission denied, show a message to the user
                Toast.makeText(
                    requireContext(),
                    "Camera permission is required to take a photo.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun takePhotoForImage(medication: Medication) {
        currentMedicationId = medication.id // Save the medication ID
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, CAMERA_REQUEST_CODE)
    }
    private var tempNewMedication: Medication? = null


    // Step 1: Update the image for the specific medication
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                GALLERY_REQUEST_CODE -> {
                    val uri = data?.data
                    uri?.let {
                        if (isAddingNewMedication) {
                            // Handle image selection for a new medication
                            val base64Image = ImageUtilities.contentUriToBase64(requireContext(), it)
                            tempNewMedication?.imageBase64 = base64Image // Update the temp medication

                            val medicationImagePreview = dialogView?.findViewById<ImageView>(R.id.medicationImagePreview)
                            //val imageView = requireView().findViewById<ImageView>(R.id.medicationImagePreview)
                            if (medicationImagePreview != null) {
                                medicationImagePreview.setImageBitmap(
                                    ImageUtilities.base64ToBitmap(
                                        base64Image
                                    )
                                )
                                //val imageView: ImageView = requireView().findViewById(R.id.imageView)
                                //imageView.setImageBitmap(ImageUtilities.base64ToBitmap(base64Image
                            }

                            Toast.makeText(requireContext(), "Image added for new medication.", Toast.LENGTH_SHORT).show()
                        } else {
                            // Handle image selection for an existing medication
                            currentMedicationId?.let { medicationId ->
                                medicationsList.find { it.id == medicationId }?.let { medication ->
                                    if (it.toString().startsWith("content://")) {
                                        val base64Image = ImageUtilities.contentUriToBase64(requireContext(), it)
                                        medication.imageBase64 = base64Image // Update the image field

                                        // Decode and display the image directly in the ImageView
                                        val imageBitmap = decodeBase64ToBitmap(medication.imageBase64 ?: "")
                                        val imageView: ImageView = requireView().findViewById(R.id.imageView)
                                        imageView.setImageBitmap(imageBitmap)

                                        // Update only the changed item in RecyclerView
                                        val position = medicationsList.indexOf(medication)
                                        medicationAdapter.notifyItemChanged(position)

                                        viewModel.updateMedication(medication) { success ->
                                            if (success) {
                                                Toast.makeText(requireContext(), "Image saved successfully!", Toast.LENGTH_SHORT).show()
                                            } else {
                                                Toast.makeText(requireContext(), "Failed to save image.", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                CAMERA_REQUEST_CODE -> {
                    val imageBitmap = data?.extras?.get("data") as? Bitmap
                    if (imageBitmap != null) {
                        val base64Image = ImageUtilities.bitmapToBase64(imageBitmap)

                        if (isAddingNewMedication) {
                            // Handle image capture for a new medication
                            tempNewMedication?.imageBase64 = base64Image // Update the temp medication

                            // Decode and display the image in the Add Medication dialog
                            val medicationImagePreview = dialogView?.findViewById<ImageView>(R.id.medicationImagePreview)
                            //val imageView = requireView().findViewById<ImageView>(R.id.medicationImagePreview)
                            if (medicationImagePreview != null) {
                                medicationImagePreview.setImageBitmap(ImageUtilities.base64ToBitmap(base64Image))
                                val imageView: ImageView = requireView().findViewById(R.id.imageView)
                                imageView.setImageBitmap(ImageUtilities.base64ToBitmap(base64Image))

                                val position = medicationsList.indexOf(tempNewMedication)
                                medicationAdapter.notifyItemChanged(position)
                                tempNewMedication?.let {
                                    viewModel.updateMedication(it) { success ->
                                        if (success) {
                                            Toast.makeText(requireContext(), "Image saved successfully!", Toast.LENGTH_SHORT).show()
                                        } else {
                                            Toast.makeText(requireContext(), "Failed to save image.", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }

                            }

                            Toast.makeText(requireContext(), "Image captured for new medication.", Toast.LENGTH_SHORT).show()
                        } else {
                            // Handle image capture for an existing medication
                            currentMedicationId?.let { medicationId ->
                                val medication = medicationsList.find { it.id == medicationId }
                                if (medication != null) {
                                    medication.imageBase64 = base64Image // Update image field

                                    // Decode and display the image directly in the ImageView
                                    val decodedBitmap = decodeBase64ToBitmap(medication.imageBase64 ?: "")
                                    val imageView: ImageView = requireView().findViewById(R.id.imageView)
                                    imageView.setImageBitmap(decodedBitmap)
                                    Toast.makeText(requireContext(), "Image added for new medication.", Toast.LENGTH_SHORT).show()

                                    // Update only the changed item in RecyclerView
                                    val position = medicationsList.indexOf(medication)
                                    medicationAdapter.notifyItemChanged(position)
                                    Toast.makeText(requireContext(), "Image added for new medication in db", Toast.LENGTH_SHORT).show()

                                    viewModel.updateMedication(medication) { success ->
                                        if (success) {
                                            Toast.makeText(requireContext(), "Image saved successfully!", Toast.LENGTH_SHORT).show()
                                        } else {
                                            Toast.makeText(requireContext(), "Failed to save image.", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        Toast.makeText(requireContext(), "Failed to capture image.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private var isAddingNewMedication: Boolean = false

    private fun openGalleryForImage(isForNewMedication: Boolean) {
        isAddingNewMedication = isForNewMedication
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, GALLERY_REQUEST_CODE)
    }

    private fun takePhotoForImage(isForNewMedication: Boolean) {
        isAddingNewMedication = isForNewMedication
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, CAMERA_REQUEST_CODE)
    }
    private fun updateImageForNewMedication() {
        // Inflate the custom dialog view
        val dialogView = LayoutInflater.from(context).inflate(R.layout.edit_image_window, null)
        val dialog = AlertDialog.Builder(requireContext())
            .setView(dialogView)
            .create()

        // Find buttons in the dialog
        val uploadButton = dialogView.findViewById<Button>(R.id.uploadButton)
        val takePhotoButton = dialogView.findViewById<Button>(R.id.takePhotoButton)
        val cancelButton = dialogView.findViewById<Button>(R.id.cancelButton)

        // Handle "Upload from Gallery" action
        uploadButton.setOnClickListener {
            openGalleryForImage(isForNewMedication = true) // Open gallery for new medication
            dialog.dismiss()
        }

        // Handle "Take Photo" action
        takePhotoButton.setOnClickListener {
            takePhotoForImage(isForNewMedication = true) // Take photo for new medication
            dialog.dismiss()
        }

        // Handle "Cancel" action
        cancelButton.setOnClickListener {
            dialog.dismiss()
        }
        // Show the dialog
        dialog.show()
    }
}