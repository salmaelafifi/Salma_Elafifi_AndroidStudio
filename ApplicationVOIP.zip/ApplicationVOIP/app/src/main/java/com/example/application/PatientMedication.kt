package com.example.application

data class PatientMedication(
    // this should be a data class
    var Quantity: Int=0,
    var id: String? = null,
    var Price: Double= 0.0,
    var name: String="",
    var Description:String="",
    //var imageUri: Uri? = null,
    var imageBase64: String? = null,
    val approval: Boolean = false
    //var imageBitmap: Bitmap? = null // Add this property to hold the image bitmap

)