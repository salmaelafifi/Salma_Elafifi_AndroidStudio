package com.example.application

import android.util.Log
import android.view.LayoutInflater
import androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class RequestsAdapter(private val requestsList: ArrayList<RequestsItem>) :
    RecyclerView.Adapter<RequestsAdapter.RequestsViewHolder>() {

    inner class RequestsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.requestTitle)
        val status: TextView = itemView.findViewById(R.id.requestStatus)
        val type: TextView = itemView.findViewById(R.id.requestType)
        val addToCartButton: Button = itemView.findViewById(R.id.addToCartButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RequestsViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_request, parent, false)
        return RequestsViewHolder(view)
    }

    override fun onBindViewHolder(holder: RequestsViewHolder, position: Int) {
        val request = requestsList[position]

        if (request.type == "Approval") {
            holder.title.text = request.title
            holder.status.text = request.status
            holder.type.text = request.type

            val currentUser = FirebaseAuth.getInstance().currentUser
            val userId = currentUser?.uid

            if (userId != null) {
                val approvalsRef = FirebaseDatabase.getInstance()
                    .getReference("users")
                    .child(userId)
                    .child("requests")
                    .child("approvals")

                // Look for matching medicationName in approvals
                approvalsRef.orderByChild("medicationName").equalTo(request.title)
                    .addListenerForSingleValueEvent(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            if (snapshot.exists()) {
                                for (approvalSnapshot in snapshot.children) {
                                    val approvalStatus = approvalSnapshot.child("status").getValue(String::class.java)

                                    if (approvalStatus == "Approved") {
                                        val medicationsRef = FirebaseDatabase.getInstance().getReference("medications")
                                        medicationsRef.orderByChild("name").equalTo(request.title).get()
                                            .addOnSuccessListener { medicationSnapshot ->
                                                if (medicationSnapshot.exists()) {
                                                    // Retrieve the first matching medication
                                                    val firstMatch = medicationSnapshot.children.firstOrNull()
                                                    if (firstMatch != null) {
                                                        // Update the "approval" field to false
                                                        firstMatch.ref.child("approval").setValue(false)
                                                            .addOnSuccessListener {
                                                                Log.d(
                                                                    "ApprovalUpdate",
                                                                    "Approval status updated to false for ${request.title}!"
                                                                )
                                                            }
                                                            .addOnFailureListener { error ->
                                                                Log.e(
                                                                    "ApprovalUpdate",
                                                                    "Failed to update approval status: ${error.message}"
                                                                )
                                                            }
                                                    } else {
                                                        Log.e("ApprovalUpdate", "No matching medication found!")
                                                    }
                                                } else {
                                                    Log.e("ApprovalUpdate", "No medications with the name ${request.title} found!")
                                                }
                                            }
                                            .addOnFailureListener { error ->
                                                Log.e("ApprovalUpdate", "Error fetching medication: ${error.message}")
                                            }
                                    } else {
                                        Log.d("ApprovalUpdate", "Approval status is not 'Approved'.")
                                    }
                                    return // Stop after finding the first match
                                }
                            } else {
                                Log.e("RequestsAdapter", "No matching approval found for ${request.title}")
                            }
                        }

                        override fun onCancelled(error: DatabaseError) {
                            Log.e("ApprovalUpdate", "Error fetching approval data: ${error.message}")
                        }
                    })

                // Handle the add to cart button click

            } else {
                //holder.addToCartButton.visibility = View.GONE
                Log.e("RequestsAdapter", "User not authenticated")
            }
        } else if (request.type == "Consultation") {
            holder.title.text = request.title
            holder.status.text = request.status
            holder.type.text = request.type
            holder.addToCartButton.visibility = View.GONE
        }
    }
    override fun getItemCount(): Int = requestsList.size
}
