package com.example.application

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class DrConsultationClass : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dr_consultation_class)

        // Check if the fragment has already been added
        if (savedInstanceState == null) {
            val consultationFragment = DrConsultationFragment()

            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, consultationFragment)
                .commit()
        }
    }
}