package com.example.application

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import android.Manifest
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.view.View


class HomePageDoctor : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference
    private lateinit var greetingTextDoc: TextView
    private lateinit var voipCallButton: ImageButton
    private var callListener: CallListener? = null
    private val REQUEST_RECORD_AUDIO_PERMISSION = 200
    private val permissions = arrayOf(android.Manifest.permission.RECORD_AUDIO)
    private var currentClientSocket: Socket? = null

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_page_doctor)
        if (!hasPermissions()) {
            requestPermissions(permissions, REQUEST_RECORD_AUDIO_PERMISSION)
        }

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().reference

        greetingTextDoc = findViewById(R.id.greetingTextDoc)
        voipCallButton = findViewById(R.id.voipCallButton)

        fetchDoctorName()

        // Initialize CallListener on the home page
        setupCallListener()


        val endCallButton: ImageButton = findViewById(R.id.endCallButton)

        // Show End Call button when call starts
        endCallButton.setOnClickListener {
            stopAudioStreaming() // Stop audio streaming
            Toast.makeText(this, "Call ended", Toast.LENGTH_SHORT).show()
            //endCallButton.visibility = View.GONE // Hide the button
        }

        // Set up navigation for buttons
        setupNavigationButtons()
    }

    private fun fetchDoctorName() {
        val currentUser = auth.currentUser
        val uid = currentUser?.uid

        if (uid != null) {
            database.child("users").child(uid).addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        val doctorName = snapshot.child("username").value?.toString() ?: "Doctor"
                        greetingTextDoc.text = "Hello, $doctorName"
                    } else {
                        greetingTextDoc.text = "Hello, Doctor"
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(
                        this@HomePageDoctor,
                        "Failed to fetch doctor name: ${error.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        } else {
            greetingTextDoc.text = "Hello, Doctor"
        }
    }

    private fun setupCallListener() {
        // Ensure any previous CallListener is stopped
        callListener?.stopListening()

        callListener = CallListener(
            port = 12346,
            onIncomingCall = { clientSocket ->
                runOnUiThread {
                    notifyIncomingCall(clientSocket)
                }
            },
            onError = { error ->
                runOnUiThread {
                    Log.e("HomePageDoctor", "Error in CallListener: ${error.message}")
                    Toast.makeText(
                        this@HomePageDoctor,
                        "Error in Call Listener: ${error.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        )

        callListener?.startListening()
        Log.d("HomePageDoctor", "CallListener started on port 12346")
    }

    private fun notifyIncomingCall(clientSocket: Socket) {
        runOnUiThread {
            // Inflate the custom dialog layout
            val dialogView = layoutInflater.inflate(R.layout.dialog_incoming_call, null)

            // Find views in the dialog layout
            val callerInfoText: TextView = dialogView.findViewById(R.id.caller_info_text)
            val callerAddress: TextView = dialogView.findViewById(R.id.caller_address)
            val answerButton: Button= dialogView.findViewById(R.id.answer_button)
            val declineButton: Button = dialogView.findViewById(R.id.decline_button)

            // Set caller information
            callerAddress.text = clientSocket.inetAddress.hostAddress
            currentClientSocket = clientSocket

            // Create and show the dialog
            val dialog = AlertDialog.Builder(this)
                .setView(dialogView)
                .setCancelable(false)
                .create()

            // Handle Answer button click
            answerButton.setOnClickListener {
                dialog.dismiss()
                startAudioStreaming(clientSocket) // Start audio streaming
                Toast.makeText(this, "Call Answered", Toast.LENGTH_SHORT).show()
            }

            // Handle Decline button click
            declineButton.setOnClickListener {
                dialog.dismiss()
                clientSocket.close() // Close the socket connection
                Toast.makeText(this, "Call Declined", Toast.LENGTH_SHORT).show()
            }

            dialog.show()
        }
    }



    private fun setupNavigationButtons() {
        val profileButton: ImageButton = findViewById(R.id.profileDoc)
        profileButton.setOnClickListener {
            val intent = Intent(this, Profile::class.java)
            startActivity(intent)
        }

        val medicationButton: ImageButton = findViewById(R.id.medicationDoc)
        medicationButton.setOnClickListener {
            val intent = Intent(this, MedicationClass::class.java)
            startActivity(intent)
        }

        val consultationButton: ImageButton = findViewById(R.id.consultationsDoc)
        consultationButton.setOnClickListener {
            val intent = Intent(this, DrConsultationClass::class.java)
            startActivity(intent)
        }

        val approvalsButton: ImageButton = findViewById(R.id.approvalsDoc)
        approvalsButton.setOnClickListener {
            val intent = Intent(this, DrRequestsActivity::class.java)
            startActivity(intent)
        }

        val mapButton: ImageButton = findViewById(R.id.mapDoc)
        mapButton.setOnClickListener {
            val intent = Intent(this, MapsActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        callListener?.stopListening()
        Log.d("HomePageDoctor", "CallListener stopped in onDestroy")
    }
    private var audioStreamingThread: Thread? = null

    private fun startAudioStreaming(socket: Socket?) {
        if (!hasPermissions()) {
            Toast.makeText(this, "Audio permission is required to stream audio", Toast.LENGTH_SHORT).show()
            return
        }

        if (socket == null) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Log.e("VoIPActivity", "Permission to record audio not granted")
            return
        }
        audioStreamingThread = Thread {
            try {
                val minBufferSize = AudioRecord.getMinBufferSize(
                    44100,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )

                val audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    44100,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    minBufferSize
                )

                val audioTrack = AudioTrack(
                    AudioManager.STREAM_VOICE_CALL,
                    44100,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    minBufferSize,
                    AudioTrack.MODE_STREAM
                )

                if (AcousticEchoCanceler.isAvailable()) {
                    val echoCanceler = AcousticEchoCanceler.create(audioRecord.audioSessionId)
                    echoCanceler.enabled = true
                }

                if (NoiseSuppressor.isAvailable()) {
                    val noiseSuppressor = NoiseSuppressor.create(audioRecord.audioSessionId)
                    noiseSuppressor.enabled = true
                }

                audioRecord.startRecording()
                audioTrack.play()

                val outputStream = socket.getOutputStream()
                val inputStream = socket.getInputStream()

                val sendBuffer = ByteArray(minBufferSize)
                val receiveBuffer = ByteArray(minBufferSize)

                while (!Thread.interrupted()) {
                    // Capture and send audio
                    val bytesRead = audioRecord.read(sendBuffer, 0, sendBuffer.size)
                    if (bytesRead > 0) {
                        outputStream.write(sendBuffer, 0, bytesRead)
                    }

                    // Receive and play audio
                    val bytesReceived = inputStream.read(receiveBuffer)
                    if (bytesReceived > 0) {
                        audioTrack.write(receiveBuffer, 0, bytesReceived)
                    }
                }

                audioRecord.stop()
                audioRecord.release()
                audioTrack.stop()
                audioTrack.release()
                socket.close()
            } catch (e: Exception) {
                Log.e("VoIPActivity", "Error in enhanced audio streaming", e)
            }
        }
        audioStreamingThread?.start()
    }


    private fun stopAudioStreaming() {
        audioStreamingThread?.interrupt()
        audioStreamingThread = null
        currentClientSocket?.close()
    }

    private fun hasPermissions(): Boolean {
        return permissions.all { perm ->
            checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_RECORD_AUDIO_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission granted", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }
}