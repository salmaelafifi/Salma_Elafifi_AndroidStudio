package com.example.application

import android.view.LayoutInflater
import androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.firebase.database.FirebaseDatabase

class CartAdapter(private val cartItemsList: ArrayList<CartItem>,private val userId: String) :
    RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    inner class CartViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val name: TextView = itemView.findViewById(R.id.cartItemName)
        val price: TextView = itemView.findViewById(R.id.cartItemPrice)
        val quantity: TextView = itemView.findViewById(R.id.cartItemQuantity)
        val removeButton: ImageButton = itemView.findViewById(R.id.removeButton)
        val increaseQuantityButton: ImageButton = itemView.findViewById(R.id.increaseQuantityButton)
        val decreaseQuantityButton: ImageButton = itemView.findViewById(R.id.decreaseQuantityButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_cart, parent, false)
        return CartViewHolder(view)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val cartItem = cartItemsList[position]
        holder.name.text = cartItem.name
        holder.price.text = "$${cartItem.price}"
        holder.quantity.text = "Quantity: ${cartItem.quantity}"

        // Remove button functionality
        holder.removeButton.setOnClickListener {
            FirebaseDatabase.getInstance()
                .getReference("users")
                .child(userId)
                .child("cart")
                .child(cartItem.name)
                .removeValue()
                .addOnSuccessListener {
                    Toast.makeText(
                        holder.itemView.context,
                        "${cartItem.name} removed from cart",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                .addOnFailureListener { error ->
                    Toast.makeText(
                        holder.itemView.context,
                        "Failed to remove item: ${error.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
        }

        // Increase quantity button functionality
        holder.increaseQuantityButton.setOnClickListener {
            val cartRef =
                FirebaseDatabase.getInstance().getReference("users").child(userId).child("cart")
            val medicationRef = FirebaseDatabase.getInstance().getReference("medications")
            medicationRef.orderByChild("name").equalTo(cartItem.name).get()
                .addOnSuccessListener { snapshot ->
                    if (snapshot.exists()) {
                        // Retrieve the first matching medication's key
                        val medicationKey = snapshot.children.firstOrNull()?.key
                        if (medicationKey != null) {
                            medicationRef.child(medicationKey).child("quantity").get()
                                .addOnSuccessListener { medicationSnapshot ->
                                    if (medicationSnapshot.exists()) {
                                        val availableQuantity = medicationSnapshot.getValue(Int::class.java) ?: 0

                                        cartRef.child(cartItem.name).child("quantity").get()
                                            .addOnSuccessListener { snapshot ->
                                                if (snapshot.exists()) {
                                                    val currentQuantity = snapshot.getValue(Int::class.java) ?: 0

                                                    if (currentQuantity + 1 > availableQuantity) {
                                                        Toast.makeText(
                                                            holder.itemView.context,
                                                            "Cannot add more. Quantity exceeds available stock for ${cartItem.name}.",
                                                            Toast.LENGTH_LONG
                                                        ).show()
                                                    } else {
                                                        cartRef.child(cartItem.name).child("quantity")
                                                            .setValue(currentQuantity + 1)
                                                            .addOnSuccessListener {
                                                                Toast.makeText(
                                                                    holder.itemView.context,
                                                                    "Increased quantity for ${cartItem.name}",
                                                                    Toast.LENGTH_SHORT
                                                                ).show()
                                                            }
                                                    }
                                                }
                                            }
                                    }
                                }
                        }
                    }
                }
        }

            // Decrease quantity button functionality
            holder.decreaseQuantityButton.setOnClickListener {
                val cartRef =
                    FirebaseDatabase.getInstance().getReference("users").child(userId).child("cart")
                cartRef.child(cartItem.name).child("quantity").get()
                    .addOnSuccessListener { snapshot ->
                        if (snapshot.exists()) {
                            val currentQuantity = snapshot.getValue(Int::class.java) ?: 1
                            if (currentQuantity > 1) {
                                cartRef.child(cartItem.name).child("quantity")
                                    .setValue(currentQuantity - 1)
                                    .addOnSuccessListener {
                                        Toast.makeText(
                                            holder.itemView.context,
                                            "Decreased quantity for ${cartItem.name}",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                            } else {
                                cartRef.child(cartItem.name).removeValue()
                                    .addOnSuccessListener {
                                        Toast.makeText(
                                            holder.itemView.context,
                                            "${cartItem.name} removed from cart",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                            }
                        }
                    }
            }
        }

        override fun getItemCount(): Int = cartItemsList.size
    }
