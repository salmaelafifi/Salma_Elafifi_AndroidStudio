package com.example.application
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import android.view.View
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.Toast
import androidx.core.content.ContentProviderCompat.requireContext
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
//import com.google.firebase.storage.FirebaseStorage


class MedicationRepository {

    private val database = FirebaseDatabase.getInstance().getReference("medications")
    //private val storage = FirebaseStorage.getInstance().reference.child("medications")

    fun saveMedication(dialogView: View, medication: Medication, onComplete: (Boolean) -> Unit) {
        val ApprovalCheckBox = dialogView.findViewById<CheckBox>(R.id.ApprovalCheckBox)
        val newMedicationRef = database.push() // Automatically generates a unique key
        medication.Approval = ApprovalCheckBox.isChecked

        medication.id = newMedicationRef.key // Set this key as the medication ID
        newMedicationRef.setValue(medication)
            .addOnSuccessListener { onComplete(true) }
            .addOnFailureListener { onComplete(false) }
    }

    fun fetchMedications(onDataFetched: (List<Medication>) -> Unit) {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val medicationList = mutableListOf<Medication>()
                for (medicationSnapshot in snapshot.children) {
                    val medication = medicationSnapshot.getValue(Medication::class.java)
                    medication?.let { medicationList.add(it) }
                }
                onDataFetched(medicationList)
            }

            override fun onCancelled(error: DatabaseError) {
                // Log the error or handle appropriately
                Log.e("MedicationRepository", "Error fetching medications: ${error.message}")
            }
        })
    }

    fun updateMedication(medication: Medication, onComplete: (Boolean) -> Unit) {
        if (medication.id != null) {
            database.child(medication.id!!).setValue(medication)
                .addOnSuccessListener { onComplete(true) }
                .addOnFailureListener { onComplete(false) }
        } else {
            onComplete(false) // ID is null; can't update
        }
    }

    fun deleteMedication(medicationId: String, onComplete: (Boolean) -> Unit) {
        database.child(medicationId).removeValue()
            .addOnSuccessListener { onComplete(true) }
            .addOnFailureListener { onComplete(false) }
    }

    fun saveImageToDatabase(medicationId: String, base64Image: String, onComplete: (Boolean) -> Unit) {
        database.child(medicationId).child("Image").setValue(base64Image)
            .addOnSuccessListener { onComplete(true) }
            .addOnFailureListener { onComplete(false) }
    }

    fun fetchMedicationImage(medicationId: String, imageView: ImageView) {
        database.child("medications").child(medicationId).child("Image").get()
            .addOnSuccessListener { snapshot ->
                val imageBase64 = snapshot.getValue(String::class.java) // Fetch the Base64 string
                if (imageBase64 != null) {
                    // Image found, call displayImage to show it
                    displayImage(imageBase64, imageView)
                } else {
                    // Handle case where image is not found
                    //Toast.makeText(requireContext, "No image found for this medication", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { exception ->
                // Handle failure to fetch image
                Log.e("FetchMedicationImage", "Error fetching image", exception)
            }
    }


    fun displayImage(base64Image: String, imageView: ImageView) {
        try {
            val decodedString: ByteArray = Base64.decode(base64Image, Base64.DEFAULT)
            val decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size)
            imageView.setImageBitmap(decodedByte)
        } catch (e: Exception) {
            e.printStackTrace()
            // Handle error
        }
    }


}