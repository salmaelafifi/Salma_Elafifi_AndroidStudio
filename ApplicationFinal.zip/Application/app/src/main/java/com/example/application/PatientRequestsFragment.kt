package com.example.application

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class PatientRequestsFragment : Fragment() {
    private lateinit var requestsRecyclerView: RecyclerView
    private lateinit var requestConsultationButton: Button
    private lateinit var requestsAdapter: RequestsAdapter
    private val requestsList = ArrayList<RequestsItem>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_patient_requests, container, false)
        requestsRecyclerView = view.findViewById(R.id.requestsRecyclerView)
        requestConsultationButton = view.findViewById(R.id.requestConsultationButton)

        requestsAdapter = RequestsAdapter(requestsList)
        requestsRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        requestsRecyclerView.adapter = requestsAdapter

        fetchRequests()

        requestConsultationButton.setOnClickListener {
            showConsultationDialog()
        }

        return view
    }

    private fun fetchRequests() {
        val currentUser = FirebaseAuth.getInstance().currentUser
        val userId = currentUser?.uid

        if (userId != null) {
            val userRequestsRef = FirebaseDatabase.getInstance().getReference("users").child(userId).child("requests")

            userRequestsRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    requestsList.clear()
                    snapshot.child("approvals").children.forEach { approval ->
                        val medicationName = approval.key ?: return
                        val status = approval.child("status").getValue(String::class.java) ?: "Unknown"
                        requestsList.add(RequestsItem(medicationName, status, "Approval"))
                    }

                    snapshot.child("consultations").children.forEach { consultation ->
                        val question = consultation.key ?: return
                        val answer = consultation.child("answer").getValue(String::class.java) ?: "No Answer Yet"
                        requestsList.add(RequestsItem(question, answer, "Consultation"))
                    }

                    requestsAdapter.notifyDataSetChanged()
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(requireContext(), "Error fetching requests", Toast.LENGTH_SHORT).show()
                }
            })
        }
    }

    private fun showConsultationDialog() {
        val dialog = AlertDialog.Builder(requireContext())
        dialog.setTitle("New Consultation")
        val input = EditText(requireContext())
        dialog.setView(input)

        dialog.setPositiveButton("Save") { _, _ ->
            val question = input.text.toString().trim()
            if (question.isNotEmpty()) {
                val currentUser = FirebaseAuth.getInstance().currentUser
                val userId = currentUser?.uid

                if (userId != null) {
                    val consultaionsRef = FirebaseDatabase.getInstance().reference.child("Consultations")
                    val userRequestsRef = FirebaseDatabase.getInstance().getReference("users").child(userId).child("requests").child("consultations")

                    val requestData = mapOf(
                        "question" to question,
                        "answer" to "")
                    val RequestData = mapOf(
                        "question" to question,
                        "clientID" to userId
                        )



                    // Save consultation to global Requests node

                    consultaionsRef.child(userId).setValue(RequestData)

                    // Save consultation to user-specific Requests node
                    userRequestsRef.child(question).setValue(requestData)

                    Toast.makeText(requireContext(), "Consultation submitted", Toast.LENGTH_SHORT).show()
                }
            }
        }
        dialog.setNegativeButton("Cancel", null)
        dialog.show()
    }
}