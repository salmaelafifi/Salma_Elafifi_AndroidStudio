package com.example.application

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class DrRequestsActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dr_requests_class)

        // Check if the fragment has already been added (to avoid recreating it on configuration changes)
        if (savedInstanceState == null) {
            val requestsFragment = DrRequestsFragment()

            // Begin fragment transaction
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragment_container, requestsFragment)
            transaction.commit()
        }
        //android.util.Log.d("MedicationClass", "Container visibility: ${findViewById<View>(R.id.fragment_container).visibility}")

    }
}