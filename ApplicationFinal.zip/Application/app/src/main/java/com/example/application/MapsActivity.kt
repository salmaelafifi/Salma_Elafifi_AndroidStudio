package com.example.application




import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MapsActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps) // Create a layout file for this activity

        // Load the MapsFragment into this activity
        if (savedInstanceState == null) {
            val fragment = MapsFragment()
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, fragment) // Use a container to place the fragment
                .commit()
        }

        val profileButton: Button= findViewById(R.id.profilebutton)

        profileButton.setOnClickListener(){
            var intentProfile=Intent(this, Profile::class.java)
            startActivity(intentProfile)

        }

        val homePage: Button= findViewById(R.id.homepage)

        homePage.setOnClickListener(){
            var intentHome=Intent(this, HomePagePatient::class.java)
            startActivity(intentHome)
        }

    }
}