package com.example.application

data class Consultation(
    //val id: String = "",
    val clientId: String = "",
    val question: String = "",
    val answer: String ="",

)

