package com.example.application

import android.util.Log
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener


class DrRequestViewModel: ViewModel() {
    private val database = FirebaseDatabase.getInstance().getReference("Approvals")
    private val _requests = MutableLiveData<List<Request>>()
    val requests: LiveData<List<Request>> get() = _requests

    fun fetchRequests(onDataFetched: (List<Request>) -> Unit) {
        database.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val requestList = mutableListOf<Request>()
                if (snapshot.exists()) {
                    for (requestSnapshot in snapshot.children) {
                        val request = requestSnapshot.getValue(Request::class.java)
                        if (request != null) {
                            requestList.add(request)
                        }
                    }
                }
                _requests.value = requestList
                onDataFetched(requestList)
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("DrRequestViewModel", "Error fetching requests: ${error.message}")
            }
        })
    }

    fun approveRequest(request: Request) {
        val approvalsDatabase = FirebaseDatabase.getInstance().getReference("Approvals")
        val clientDatabase = FirebaseDatabase.getInstance()
            .getReference("users")
            .child(request.clientId)
            .child("requests")
            .child("approvals")
            .child(request.medicationName)

        // Update the status in the user's requests database
        clientDatabase.child("status").setValue("Approved")
            .addOnSuccessListener {
                Log.d("ApproveRequest", "Approval status updated for ${request.medicationName}")

                // Remove the request from the global Approvals node
                approvalsDatabase.child(request.medicationName).removeValue()
                    .addOnSuccessListener {
                        Log.d("ApproveRequest", "Request removed from global Approvals database.")
                        // Optionally, update the UI or notify the user
                        _requests.value = _requests.value?.filterNot { it.medicationName == request.medicationName }
                    }
                    .addOnFailureListener { error ->
                        Log.e("ApproveRequest", "Failed to remove request from Approvals: ${error.message}")
                    }
            }
            .addOnFailureListener { error ->
                Log.e("ApproveRequest", "Failed to update approval status: ${error.message}")
            }
    }

    fun declineRequest(request: Request) {
        val DeclinesDatabase = FirebaseDatabase.getInstance().getReference("Approvals")
        //val database = FirebaseDatabase.getInstance().getReference("Requests")

        // Create a map or object to store in the "Approvals" database
        val declineData = mapOf(
            "clientId" to request.clientId,
            "medicationName" to request.medicationName

        )

        // Add the approval data to the database
        //DeclinesDatabase.push().setValue(declineData)
            //.addOnSuccessListener {
                //og.d("DeclineRequest", "Request Declined and saved to Declines database.")
            //}
            //.addOnFailureListener { error ->
                //Log.e("DeclineRequest", "Failed to save Decline: ${error.message}")
            //}
        DeclinesDatabase.child(request.clientId).removeValue()
            .addOnSuccessListener {
                Log.d("DeclineRequest", "Request removed from Requests database.")
                // You can notify the UI to remove the item from the list
                _requests.value = _requests.value?.filterNot { it.clientId == request.clientId }
            }
            .addOnFailureListener { error ->
                Log.e("DeclineRequest", "Failed to remove request: ${error.message}")
            }
    }
}
