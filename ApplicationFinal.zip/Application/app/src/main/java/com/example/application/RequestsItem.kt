package com.example.application

data class RequestsItem(
    val title: String = "", // Represents medication name or consultation question
    val status: String = "", // Represents approval status or consultation answer
    val type: String = "",
    val answer: String="",
    val clientId: String="",
    val medicationId:String=""
    //val id: Int
)