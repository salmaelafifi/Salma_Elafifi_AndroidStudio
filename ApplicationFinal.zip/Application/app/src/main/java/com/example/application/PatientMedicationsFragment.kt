package com.example.application

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DatabaseReference
import androidx.recyclerview.widget.GridLayoutManager
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError


class PatientMedicationsFragment : Fragment() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var patientMedicationsAdapter: PatientMedicationsAdapter
    private lateinit var medicationsList: ArrayList<PatientMedication>
    private lateinit var database: DatabaseReference
    private val _medications = MutableLiveData<List< PatientMedication>>()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_patient_medications, container, false)
        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = GridLayoutManager(context, 2) // 2 columns for grid layout

        database = FirebaseDatabase.getInstance().getReference("medications")

        medicationsList = ArrayList()
        patientMedicationsAdapter = PatientMedicationsAdapter(medicationsList)
        recyclerView.adapter = patientMedicationsAdapter

        loadMedicationsData()

        return view
    }

    private fun loadMedicationsData() {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                medicationsList.clear()
                for (medSnapshot in snapshot.children) {
                    // Get the medicationId as key
                    val patientMedication = medSnapshot.getValue(PatientMedication::class.java)

                    // You can still use medicationId if needed
                    if (patientMedication != null) {
                        medicationsList.add(patientMedication)
                    }
                }
                patientMedicationsAdapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(context, "Failed to load data", Toast.LENGTH_SHORT).show()
            }
        })
    }




}