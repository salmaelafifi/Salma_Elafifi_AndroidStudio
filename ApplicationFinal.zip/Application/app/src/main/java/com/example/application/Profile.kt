package com.example.application

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.auth.FirebaseAuth

class Profile : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference
    private lateinit var bioTextView: TextView
    private lateinit var bioEditText: EditText
    private lateinit var usernameTextView: TextView
    private lateinit var emailTextView: TextView
    private lateinit var passwordTextView: TextView
    private lateinit var usernameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var genderTextView: TextView
    private lateinit var usertypeTextView: TextView
    private lateinit var editButton: Button
    private lateinit var saveButton: Button
    private val BIO_KEY = "bio_key"
    private val USERNAME_KEY = "username_key"
    private val PASSWORD_KEY = "password_key"
    private val PREFS_NAME = "profile_prefs"

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_profile)
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().reference

        bioTextView = findViewById(R.id.bioTextView)
        bioEditText = findViewById(R.id.bioEditText)
        usernameTextView = findViewById(R.id.usernameText)
        usernameEditText = findViewById(R.id.usernameEdit)
        emailTextView = findViewById(R.id.emailText)
        passwordTextView = findViewById(R.id.passwordText)
        passwordEditText = findViewById(R.id.passwordEdit)
        genderTextView = findViewById(R.id.genderText)
        usertypeTextView = findViewById(R.id.userText)
        editButton = findViewById(R.id.editButton)
        saveButton = findViewById(R.id.saveButton)

        val sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedBio = sharedPreferences.getString(BIO_KEY, "This is my bio.") // Default text
        bioTextView.text = savedBio

        val uid = auth.currentUser?.uid
        if (uid != null) {
            database.child("users").child(uid).get().addOnSuccessListener { snapshot ->
                if (snapshot.exists()) {
                    val savedUsername = sharedPreferences.getString(USERNAME_KEY, snapshot.child("username").value.toString())
                    val savedEmail = snapshot.child("email").value.toString()
                    val savedUsertype = snapshot.child("userType").value.toString()
                    val savedGender = snapshot.child("gender").value.toString()
                    val savedPassword = sharedPreferences.getString(PASSWORD_KEY, snapshot.child("password").value.toString())

                    usernameTextView.text = savedUsername
                    emailTextView.text = savedEmail
                    genderTextView.text = savedGender
                    passwordTextView.text = savedPassword
                    usertypeTextView.text = savedUsertype

                }
            }.addOnFailureListener {
                Toast.makeText(this, "Failed to load profile", Toast.LENGTH_SHORT).show()
            }
        }
        editButton.setOnClickListener {
            usernameTextView.visibility = View.GONE
            passwordTextView.visibility = View.GONE
            bioTextView.visibility = View.GONE
            usernameEditText.visibility = View.VISIBLE
            passwordEditText.visibility = View.VISIBLE
            bioEditText.visibility = View.VISIBLE
            editButton.visibility = View.GONE
            saveButton.visibility = View.VISIBLE

            usernameEditText.setText(usernameTextView.text)
            passwordEditText.setText(passwordTextView.text)
            bioEditText.setText(bioTextView.text)

        }






        saveButton.setOnClickListener {
            val bio = bioEditText.text.toString()
            bioTextView.text = bio
            val editor = sharedPreferences.edit()
            editor.putString(BIO_KEY, bio)

            val Username = usernameEditText.text.toString()
            usernameTextView.text = Username
            editor.putString(USERNAME_KEY, Username)

            val Password = passwordEditText.text.toString()
            passwordTextView.text = Password
            editor.putString(PASSWORD_KEY, Password)

            editor.apply()

            val uid = auth.currentUser?.uid
            if (uid != null) {
                // Prepare the map with updates
                val userUpdates = mutableMapOf<String, Any>()
                userUpdates["username"] = Username
                // Note: You typically don't store plain passwords directly in the database
                userUpdates["password"] = Password

                // Update the database with new username and password
                database.child("users").child(uid).updateChildren(userUpdates)
                    .addOnSuccessListener {
                        Toast.makeText(this, "Profile updated in database", Toast.LENGTH_SHORT)
                            .show()
                    }.addOnFailureListener {
                    Toast.makeText(this, "Failed to update profile in database", Toast.LENGTH_SHORT)
                        .show()
                }



                bioTextView.visibility = View.VISIBLE
                bioEditText.visibility = View.GONE
                usernameEditText.visibility = View.GONE
                usernameTextView.visibility = View.VISIBLE
                passwordEditText.visibility = View.GONE
                passwordTextView.visibility = View.VISIBLE
                editButton.visibility = View.VISIBLE
                saveButton.visibility = View.GONE


            }


            val MapButton: Button = findViewById(R.id.buttonMap)

            MapButton.setOnClickListener() {
                var MapIntent = Intent(this, MapsActivity::class.java)
                startActivity(MapIntent)
            }


        }
    }
}