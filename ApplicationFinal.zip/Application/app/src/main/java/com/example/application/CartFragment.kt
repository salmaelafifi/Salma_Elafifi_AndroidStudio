package com.example.application

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class CartFragment : Fragment() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var cartAdapter: CartAdapter
    private lateinit var cartItemsList: ArrayList<CartItem>
    private lateinit var database: DatabaseReference
    private lateinit var userId: String

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_cart, container, false)

        // Initialize RecyclerView
        recyclerView = view.findViewById(R.id.recyclerViewCart)
        recyclerView.layoutManager = LinearLayoutManager(context)

        // Get the current user's UID
        val currentUser = FirebaseAuth.getInstance().currentUser
        userId = currentUser?.uid ?: ""

        // Initialize Firebase Database reference for the cart
        database = FirebaseDatabase.getInstance().getReference("users").child(userId).child("cart")

        // Initialize cart items list and adapter
        cartItemsList = ArrayList()
        cartAdapter = CartAdapter(cartItemsList,userId)
        recyclerView.adapter = cartAdapter

        // Load cart items from Firebase
        loadCartData()

        return view
    }

    private fun loadCartData() {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                cartItemsList.clear()
                var totalPrice = 0.0
                for (cartSnapshot in snapshot.children) {
                    val cartItem = cartSnapshot.getValue(CartItem::class.java)
                    if (cartItem != null) {
                        val medicationName=cartSnapshot.key ?: "" // Use the key as the name
                        cartItem.name = medicationName// Use the key as the name
                        cartItemsList.add(cartItem)
                        totalPrice += cartItem.quantity * cartItem.price
                    }
                }
                cartAdapter.notifyDataSetChanged()
                view?.findViewById<TextView>(R.id.totalPriceText)?.text = "Total: $$totalPrice"
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(context, "Failed to load cart", Toast.LENGTH_SHORT).show()
            }
        })
    }
    fun refreshCart() {
        cartItemsList.clear()  // Clear the list
        cartAdapter.notifyDataSetChanged()  // Notify the adapter to update the RecyclerView

        // Optionally, you can also show a message that the cart has been cleared:
        Toast.makeText(requireContext(), "Cart is empty", Toast.LENGTH_SHORT).show()
    }
}