package com.example.application

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textfield.TextInputEditText

class DrConsultationAdapter(private val onAnswerSubmit: (Consultation, String) -> Unit) : RecyclerView.Adapter<DrConsultationAdapter.ConsultationViewHolder>() {
    private val consultationList = mutableListOf<Consultation>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ConsultationViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.consultation_view, parent, false)
        return ConsultationViewHolder(view)
    }

    override fun onBindViewHolder(holder: ConsultationViewHolder, position: Int) {
        val consultation = consultationList[position]
        holder.bind(consultation)
    }

    fun submitList(newList: List<Consultation>) {
        consultationList.clear()
        consultationList.addAll(newList)
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = consultationList.size

    inner class ConsultationViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val messageTextView: TextView? = itemView.findViewById(R.id.messageTextView)
        private val answerInputEditText: TextInputEditText? = itemView.findViewById(R.id.answerInputEditText)
        private val answerButton: Button? = itemView.findViewById(R.id.answerButton)

        fun bind(consultation: Consultation) {
            messageTextView?.text = consultation.question

            answerButton?.setOnClickListener {
                val answer = answerInputEditText?.text.toString().trim()
                if (answer.isNotEmpty()) {
                    // Submit the answer when the button is clicked
                    onAnswerSubmit(consultation, answer)
                    answerInputEditText?.text?.clear()  // Clear input after submission
                } else {
                    Toast.makeText(itemView.context, "Please enter a response", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}