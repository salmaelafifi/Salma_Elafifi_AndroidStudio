package com.example.application

import android.R.attr.name
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import androidx.appcompat.app.AlertDialog
import com.google.android.play.integrity.internal.q
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener

class CartActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_cart)
        val userId = FirebaseAuth.getInstance().currentUser?.uid

        val clearCartButton: ImageButton = findViewById(R.id.clearCartButton)
        val checkoutButton: ImageButton = findViewById(R.id.checkoutButton)

        if (userId != null) {
        checkoutButton.setOnClickListener {
            Toast.makeText(this, "Checkout button clicked", Toast.LENGTH_SHORT).show()
            performCheckout(userId)
        }
            }

        if (userId != null) {
            clearCartButton.setOnClickListener {
                clearCart(userId)
            }
        } else {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
        }

        if (savedInstanceState == null) {
            val cartFragment = CartFragment()
            supportFragmentManager.beginTransaction()
                .replace(R.id.cartFragmentContainer, cartFragment).commit()
        }
    }

    private fun clearCart(userId: String) {
        val cartRef =
            FirebaseDatabase.getInstance().getReference("users").child(userId).child("cart")
        cartRef.removeValue().addOnSuccessListener {
            Toast.makeText(this, "Cart cleared", Toast.LENGTH_SHORT).show()
            val fragment = supportFragmentManager.findFragmentById(R.id.cartFragmentContainer)
            if (fragment is CartFragment) {
                fragment.refreshCart()
            }
        }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to clear cart", Toast.LENGTH_SHORT).show()
            }
    }

    fun getCartItems(userId: String, onResult: (List<Map<String, Any>>) -> Unit, onError: (String) -> Unit) {
        val cartRef = FirebaseDatabase.getInstance().getReference("users")
            .child(userId)
            .child("cart")

        cartRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val cartItems = mutableListOf<Map<String, Any>>()

                    for (itemSnapshot in snapshot.children) {
                        val itemDetails = itemSnapshot.value as? Map<String, Any>
                        if (itemDetails != null) {
                            cartItems.add(itemDetails)
                        }
                    }

                    // Return the list of items through the callback
                    onResult(cartItems)
                } else {
                    // Return an empty list if no items exist
                    onResult(emptyList())
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle the error by invoking the error callback
                onError("Error reading cart data: ${error.message}")
            }
        })
    }





    private fun performCheckout(userId: String?) {
        getCartItems(
            userId = userId.toString(),
            onResult = { cartItems ->
                // Loop through each item in the cartItems list
                for (item in cartItems) {
                    val itemName = item["name"] as? String ?: "Unknown"
                    val itemquantity = item["quantity"] as? Int ?: 0

                    checkQuantityAndUpdateStock(
                        cartItemName = itemName,
                        cartItemQuantity = itemquantity,
                        onSuccess = { isEnoughStock ->
                            if (isEnoughStock) {
                                println("Stock is sufficient for $name")
                            } else {
                                println("Insufficient stock for $name")
                            }
                        },
                        onError = { error ->
                            println("Error: $error")
                        }
                    )
                }
            },

            onError = { errorMessage ->
                println("Error: $errorMessage")
            }
        )


    }
    fun checkQuantity(
        cartItemName: String,
        cartItemQuantity: Int,
        onSuccess: (Boolean) -> Unit,
        onError: (String) -> Unit
    ) {
        getMedicationByName(
            medicationName = cartItemName,
            onResult = { medication ->
                if (medication != null) {
                    // Extract the quantity of the medication
                    val medicationQuantity = medication["quantity"] as? Long ?: 0L

                    // Compare quantities
                    if (medicationQuantity > cartItemQuantity) {
                        onSuccess(true) // Enough stock available
                    } else {
                        onSuccess(false) // Not enough stock
                    }
                } else {
                    onError("PatientMedication not found")
                }
            },
            onError = { error ->
                onError(error)
            }
        )
    }
    fun updateMedicationStock(
        medicationName: String,
        updatedStock: Long,
        onSuccess: (Boolean) -> Unit,
        onError: (String) -> Unit
    ) {
        val medicationRef = FirebaseDatabase.getInstance().getReference("medications").child(medicationName)

        medicationRef.child("quantity").setValue(updatedStock)
            .addOnSuccessListener {
                // Successfully updated the stock
                onSuccess(true)
            }
            .addOnFailureListener { error ->
                // Failed to update the stock
                onError("Error updating stock: ${error.message}")
            }
    }

    fun checkQuantityAndUpdateStock(
        cartItemName: String,
        cartItemQuantity: Int,
        onSuccess: (Boolean) -> Unit,
        onError: (String) -> Unit
    ) {
        getMedicationByName(
            medicationName = cartItemName,
            onResult = { medication ->
                if (medication != null) {
                    // Extract the current quantity of the medication
                    val currentStock = medication["quantity"] as? Long ?: 0L

                    // Compare quantities
                    if (currentStock >= cartItemQuantity) {
                        // Enough stock available, proceed to update
                        val updatedStock = currentStock - cartItemQuantity
                        // Update the stock in the database
                        updateMedicationStock(cartItemName, updatedStock, onSuccess, onError)
                    } else {
                        // Not enough stock
                        onSuccess(false)
                    }
                } else {
                    // PatientMedication not found
                    onError("PatientMedication not found")
                }
            },
            onError = { error ->
                // Handle error while retrieving medication
                onError(error)
            }
        )
    }






    fun getMedicationByName(
        medicationName: String,
        onResult: (Map<String, Any>?) -> Unit,
        onError: (String) -> Unit
    ) {
        val medicationsRef = FirebaseDatabase.getInstance().getReference("medications")

        // Query to find a medication by name
        medicationsRef.orderByChild("name").equalTo(medicationName)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        // Assuming there's only one medication with this name
                        val medication = snapshot.children.firstOrNull()?.value as? Map<String, Any>
                        onResult(medication)
                    } else {
                        onResult(null) // No medication found
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    onError("Error querying medication: ${error.message}")
                }
            })
    }



}

