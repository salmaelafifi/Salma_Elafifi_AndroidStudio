package com.example.application

import android.graphics.Bitmap
import android.util.Log
import android.view.View
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.database.FirebaseDatabase

class MedicationViewModel : ViewModel() {

    private val repository = MedicationRepository()

    private val _medications = MutableLiveData<List<Medication>>()
    val medications: LiveData<List<Medication>> get() = _medications

    fun fetchMedications() {
        repository.fetchMedications { medicationList ->
            _medications.postValue(medicationList)
        }
    }

    fun saveMedication(dialogView: View,medication: Medication, onComplete: (Boolean) -> Unit) {
        repository.saveMedication(dialogView,medication, onComplete)
    }

    fun updateMedication(medication: Medication, onComplete: (Boolean) -> Unit) {
        repository.updateMedication(medication, onComplete)
    }

    fun deleteMedication(medicationId: String, onComplete: (Boolean) -> Unit) {
        repository.deleteMedication(medicationId, onComplete)
    }

    fun saveMedicationImage(medicationId: String, bitmap: Bitmap, onComplete: (Boolean) -> Unit) {
        val base64Image = ImageUtilities.encodeBitmapToBase64(bitmap)
        repository.saveImageToDatabase(medicationId, base64Image, onComplete)
    }

    fun fetchMedicationImage(medicationId: String, onComplete: (Bitmap?) -> Unit) {
        // Access the Firebase database reference for medications
        val medicationRef = FirebaseDatabase.getInstance().getReference("medications").child(medicationId)

        medicationRef.child("imageBase64").get().addOnSuccessListener { snapshot ->
            // Check if the snapshot contains the 'imageBase64' field
            val base64Image = snapshot.getValue(String::class.java)

            // Decode the Base64 string to Bitmap
            val bitmap = base64Image?.let { ImageUtilities.decodeBase64ToBitmap(it) }

            // Return the decoded Bitmap via the callback
            onComplete(bitmap)
        }.addOnFailureListener { exception ->
            // Handle failure (e.g., if the image fetching fails)
            Log.e("fetchMedicationImage", "Error fetching medication image: ${exception.message}")
            onComplete(null)  // Return null if there is an error
        }
    }

}