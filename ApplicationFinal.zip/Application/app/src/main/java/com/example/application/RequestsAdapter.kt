package com.example.application

import android.view.LayoutInflater
import androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class RequestsAdapter(private val requestsList: ArrayList<RequestsItem>) :
    RecyclerView.Adapter<RequestsAdapter.RequestsViewHolder>() {

    inner class RequestsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.requestTitle)
        val status: TextView = itemView.findViewById(R.id.requestStatus)
        val type: TextView = itemView.findViewById(R.id.requestType)
        val addToCartButton: Button = itemView.findViewById(R.id.addToCartButton)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RequestsViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_request, parent, false)
        return RequestsViewHolder(view)
    }

    override fun onBindViewHolder(holder: RequestsViewHolder, position: Int) {
        val request = requestsList[position]

        // If it's an approval request
        if (request.type == "Approval") {
            holder.title.text = request.title
            holder.status.text = request.status
            holder.type.text = request.type

            // Check if the medication is approved globally in the "approvals" node
            val currentUser = FirebaseAuth.getInstance().currentUser
            val userId = currentUser?.uid

            if (userId != null) {
                val approvalRef = FirebaseDatabase.getInstance().getReference("users").child(userId)
                    .child("requests").child("approvals").child(request.title)

                // Listen for approval status
                approvalRef.addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val approvalStatus = snapshot.child("status").getValue(String::class.java)

                        if (approvalStatus == "Approved") {
                            // PatientMedication approved, show "Add to Cart" button
                            holder.addToCartButton.visibility = View.VISIBLE

                        } else {
                            // PatientMedication pending approval, show "Request Approval" button
                            holder.addToCartButton.visibility = View.GONE

                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Toast.makeText(
                            holder.itemView.context,
                            "Error fetching approval status",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                })
            }

            // Handle the add to cart button click
            holder.addToCartButton.setOnClickListener {
                val currentUser = FirebaseAuth.getInstance().currentUser
                val userId = currentUser?.uid

                if (userId != null) {
                    val medicationsRef = FirebaseDatabase.getInstance().getReference("medications")
                    val cartRef = FirebaseDatabase.getInstance().getReference("users").child(userId).child("cart")

                    // Query the medications database to find the record with the matching medicationName
                    medicationsRef.orderByChild("name").equalTo(request.title.toString()).get()
                        .addOnSuccessListener { snapshot ->
                            if (snapshot.exists()) {
                                // Retrieve the first matching medication
                                val medicationSnapshot = snapshot.children.firstOrNull()
                                val medication =
                                    medicationSnapshot?.getValue(PatientMedication::class.java)

                                if (medication != null) {
                                    // Add to cart using medication Name as the key
                                    cartRef.child(medication.name).get()
                                        .addOnSuccessListener { cartSnapshot ->
                                            if (cartSnapshot.exists()) {
                                                // If the medication is already in the cart, update the quantity
                                                val existingQuantity =
                                                    cartSnapshot.child("quantity")
                                                        .getValue(Long::class.java) ?: 0L
                                                cartRef.child(medication.name).child("quantity")
                                                    .setValue(existingQuantity + 1)
                                            } else {
                                                // If it's a new medication, add it to the cart with quantity 1
                                                val cartItem = mapOf(

                                                    "quantity" to 1L,
                                                    "price" to medication.Price
                                                )
                                                cartRef.child(medication.name).setValue(cartItem)
                                            }

                                            // Show success message
                                            Toast.makeText(
                                                holder.itemView.context,
                                                "${medication.name} added to cart",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                } else {
                                    Toast.makeText(
                                        holder.itemView.context,
                                        "Failed to retrieve medication details",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            } else {
                                Toast.makeText(
                                    holder.itemView.context,
                                    "Medication not found in database",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                        .addOnFailureListener {
                            Toast.makeText(
                                holder.itemView.context,
                                "Failed to query medications",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                } else {
                    Toast.makeText(
                        holder.itemView.context,
                        "User not authenticated",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        // If it's a consultation request
        else if (request.type == "Consultation") {
            holder.title.text = request.title
            holder.status.text = request.status
            holder.type.text = request.type
            holder.addToCartButton.visibility = View.GONE

        }
    }

    override fun getItemCount(): Int = requestsList.size
}