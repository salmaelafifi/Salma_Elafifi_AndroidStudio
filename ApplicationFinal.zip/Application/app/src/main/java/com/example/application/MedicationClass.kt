package com.example.application

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class MedicationClass: AppCompatActivity()  {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.medication_class)

        // Check if the fragment has already been added (to avoid recreating it on configuration changes)
        if (savedInstanceState == null) {
            val medicationFragment = MedicationFragment()

            // Begin fragment transaction
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragment_container, medicationFragment)
            transaction.commit()
        }
        //android.util.Log.d("MedicationClass", "Container visibility: ${findViewById<View>(R.id.fragment_container).visibility}")

    }

}