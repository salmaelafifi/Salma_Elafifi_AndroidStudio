package com.example.application

import android.graphics.Bitmap
import android.net.Uri

 data class Medication(

    // this should be a data class
     var Quantity: Int=0,
     var id: String? = null,
     var Price: Double= 0.0,
     var Name: String="",
     var Description:String="",
     //var imageUri: Uri? = null,
     var imageBase64: String? = null,
     var Approval: Boolean = false
     //var imageBitmap: Bitmap? = null // Add this property to hold the image bitmap

 )
