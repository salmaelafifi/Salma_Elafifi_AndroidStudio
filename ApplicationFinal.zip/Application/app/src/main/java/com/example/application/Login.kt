package com.example.application

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class Login : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login)

        // Initialize Firebase Authentication and Database references
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().reference

        // Get input fields
        val emailInput: TextInputEditText = findViewById(R.id.Email)
        val passwordInput: TextInputEditText = findViewById(R.id.Password)
        val loginButton: Button = findViewById(R.id.buttonLogin)
        val registerButton: Button = findViewById(R.id.buttonRegister)

        // Handle Register button click
        registerButton.setOnClickListener {
            val intentRegister = Intent(this, Register::class.java)
            startActivity(intentRegister)
        }

        // Handle Login button click
        loginButton.setOnClickListener {
            val userEmail = emailInput.text.toString()
            val userPassword = passwordInput.text.toString()

            if (userEmail.isNotEmpty() && userPassword.isNotEmpty()) {
                auth.signInWithEmailAndPassword(userEmail, userPassword).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val uid = auth.currentUser?.uid
                        if (uid != null) {
                            // Fetch userType from Firebase Realtime Database
                            database.child("users").child(uid).get().addOnSuccessListener { snapshot ->
                                if (snapshot.exists()) {
                                    val userType = snapshot.child("userType").value.toString()

                                    // Navigate to the appropriate homepage based on userType
                                    if (userType == "Patient") {
                                        startActivity(Intent(this, HomePagePatient::class.java))
                                    } else if (userType == "Doctor") {
                                        startActivity(Intent(this, HomePageDoctor::class.java))
                                    } else {
                                        Toast.makeText(this, "Unknown user type", Toast.LENGTH_SHORT).show()
                                    }
                                    finish()
                                } else {
                                    Toast.makeText(this, "User data not found", Toast.LENGTH_SHORT).show()
                                }
                            }.addOnFailureListener {
                                Toast.makeText(this, "Failed to retrieve user data", Toast.LENGTH_SHORT).show()
                            }
                        }
                    } else {
                        Toast.makeText(this, "Sign-In Failed", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                Toast.makeText(this, "Please fill in all fields to Sign-In", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

