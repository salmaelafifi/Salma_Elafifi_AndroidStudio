package com.example.application

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.fragment.app.viewModels

class DrRequestsFragment: Fragment() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: DrRequestsAdapter
    private val viewModel: DrRequestViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.dr_requests_fragment, container, false)
        recyclerView = view.findViewById(R.id.recyclerView)
        setupRecyclerView()
        observeData()

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Call fetchRequests method
        viewModel.fetchRequests { requestList ->
            // Update the RecyclerView with fetched data
            adapter.submitList(requestList)
        }
    }

    private fun setupRecyclerView() {
        recyclerView.layoutManager = GridLayoutManager(context, 2)
        adapter = DrRequestsAdapter { request, action ->
            handleAction(request, action)
        }
        recyclerView.adapter = adapter
    }

    private fun observeData() {
        viewModel.requests.observe(viewLifecycleOwner) { requests ->
            adapter.submitList(requests)
        }
    }

    private fun handleAction(request: Request, action: String) {
        when (action) {
            "approve" -> viewModel.approveRequest(request)
            "decline" -> viewModel.declineRequest(request)
            //"answer" -> openAnswerDialog(request)
        }
    }


}