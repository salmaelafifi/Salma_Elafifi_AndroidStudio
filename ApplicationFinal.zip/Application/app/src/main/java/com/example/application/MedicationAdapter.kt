package com.example.application
import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
class MedicationAdapter(
    private var medicationList: MutableList<Medication>, // Use MutableList for flexibility
    private val viewModel: MedicationViewModel,
    private val onEditClick: (Medication) -> Unit,
    private val onImageClick: (Medication) -> Unit
) : RecyclerView.Adapter<MedicationAdapter.ItemViewHolder>() {

    // ViewHolder class to hold view references for each item
    class ItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titleTextView: TextView = itemView.findViewById(R.id.nameTextView)
        val priceTextView: TextView = itemView.findViewById(R.id.priceTextView)
        val quantityTextView: TextView = itemView.findViewById(R.id.QuantityTextView)
        val imageView: ImageView = itemView.findViewById(R.id.imageView)
        val editButton: Button = itemView.findViewById(R.id.editButton)
        val description: TextView= itemView.findViewById(R.id.MedicationDescription)
        //val approvalCheckBox: CheckBox = itemView.findViewById(R.id.ApprovalCheckBox)


    }

    // Inflates the item layout and creates a ViewHolder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.medication_view, parent, false)
        return ItemViewHolder(view)
    }

    // Binds data to the views in each ViewHolder
    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = medicationList[position]

        // Bind medication details
        holder.titleTextView.text = item.Name
        holder.priceTextView.text = item.Price.toString()
        holder.quantityTextView.text = item.Quantity.toString()
        holder.description.text= item.Description
        //holder.approvalCheckBox.isChecked = item.Approval

        // Handle CheckBox state change
        //older.approvalCheckBox.setOnCheckedChangeListener { _, isChecked ->
            //item.Approval = true
        //}//viewModel.updateApproval(item) // Optional: Use a ViewModel method to persist the change


        if (!item.imageBase64.isNullOrEmpty()) {
            val bitmap = ImageUtilities.base64ToBitmap(item.imageBase64!!)
            holder.imageView.setImageBitmap(bitmap)
        } else {
            //holder.imageView.setImageResource(R.drawable.placeholder_image) // Default image
        }

        // Handle click events
        holder.editButton.setOnClickListener { onEditClick(item) }
        holder.imageView.setOnClickListener { onImageClick(item)}

        item.id?.let {
            viewModel.fetchMedicationImage(it) { bitmap ->
                if (bitmap != null) {
                    holder.imageView.setImageBitmap(bitmap)
                } else {
                    holder.imageView.setImageResource(R.drawable.placeholder) // Set a placeholder in case of failure
                }
            }
        }
    }

    // Returns the total number of items in the data set
    override fun getItemCount(): Int = medicationList.size

    // Function to update the data set and notify the adapter
    fun updateData(newList: List<Medication>) {
        medicationList.clear()
        medicationList.addAll(newList)
        notifyDataSetChanged()
    }

    // Function to remove an item
    fun removeItem(position: Int) {
        if (position in medicationList.indices) {
            medicationList.removeAt(position)
            notifyItemRemoved(position)
        }
    }


}


