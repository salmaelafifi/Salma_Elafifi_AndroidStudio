package com.example.application

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.application.HomePagePatient
import com.example.application.DrConsultationClass
import com.example.application.DrRequestsActivity
import com.example.application.MedicationClass
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
class HomePageDoctor : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: DatabaseReference
    private lateinit var greetingTextDoc: TextView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_page_doctor)

        auth = Firebase.auth
        database = FirebaseDatabase.getInstance().reference

        greetingTextDoc = findViewById(R.id.greetingTextDoc)

        // Get the current doctor data from Firebase
        val currentUser = auth.currentUser
        val uid = currentUser?.uid

        if (uid != null) {
            // Listen for changes in the doctor's data
            database.child("users").child(uid).addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        val doctorName = snapshot.child("username").value?.toString() ?: "Doctor"
                        greetingTextDoc.text = "Hello, $doctorName"
                    } else {
                        greetingTextDoc.text = "Hello, Doctor"
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    // Handle database error
                    Toast.makeText(
                        this@HomePageDoctor,
                        "Failed to fetch doctor name: ${error.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        } else {
            greetingTextDoc.text = "Hello, Doctor"
        }

        // Set up navigation buttons
        val profileButton: ImageButton = findViewById(R.id.profileDoc)
        profileButton.setOnClickListener {
            val intentProfile = Intent(this, Profile::class.java)
            startActivity(intentProfile)
        }

        val medicationButton: ImageButton = findViewById(R.id.medicationDoc)
        medicationButton.setOnClickListener {
            val intentMedications = Intent(this, MedicationClass::class.java)
            startActivity(intentMedications)
        }

        val consultationButton: ImageButton = findViewById(R.id.consultationsDoc)
        consultationButton.setOnClickListener {
            val intent = Intent(this, DrConsultationClass::class.java)
            Log.d("DrConsultationClass", "Starting fragment transaction")

            startActivity(intent)
        }

        val approvalsButton: ImageButton = findViewById(R.id.approvalsDoc)
        approvalsButton.setOnClickListener {
            val intentApprovals = Intent(this, DrRequestsActivity::class.java)
            startActivity(intentApprovals)
        }

        val mapButton: ImageButton = findViewById(R.id.mapDoc)
        mapButton.setOnClickListener {
            val intentMap = Intent(this, MapsActivity::class.java)
            startActivity(intentMap)
        }
    }
}