package com.example.application

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class DrRequestsAdapter (
    private val onActionClick: (Request, String) -> Unit)
    : ListAdapter<Request, DrRequestsAdapter.RequestViewHolder>(DiffCallback()){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RequestViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.request_view, parent, false)
        return RequestViewHolder(view)
    }

    override fun onBindViewHolder(holder: RequestViewHolder, position: Int) {
        val request = getItem(position)
        holder.bind(request)
    }

    inner class RequestViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val title = itemView.findViewById<TextView>(R.id.requestTitle)
        private val details = itemView.findViewById<TextView>(R.id.requestDetails)
        private val approveButton = itemView.findViewById<Button>(R.id.approveButton)
        private val declineButton = itemView.findViewById<Button>(R.id.declineButton)
        //private val answerButton = itemView.findViewById<Button>(R.id.answerButton)

        fun bind(request: Request) {
            title.text = request.medicationName
            //details.text = request.details

            approveButton.setOnClickListener { onActionClick(request, "approve") }
            declineButton.setOnClickListener { onActionClick(request, "decline") }
            //answerButton.setOnClickListener { onActionClick(request, "answer") }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<Request>() {
        override fun areItemsTheSame(oldItem: Request, newItem: Request): Boolean {
            return oldItem.clientId == newItem.clientId
        }

        override fun areContentsTheSame(oldItem: Request, newItem: Request): Boolean {
            return oldItem == newItem
        }
    }
}
