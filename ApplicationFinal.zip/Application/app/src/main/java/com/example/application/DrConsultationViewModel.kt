package com.example.application

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class DrConsultationViewModel : ViewModel() {
    private val database = FirebaseDatabase.getInstance().getReference("Consultations")
    private val _consultations = MutableLiveData<List<Consultation>>()
    val consultations: LiveData<List<Consultation>> get() = _consultations

    // Fetch consultations
    fun fetchConsultations() {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val consultationList = mutableListOf<Consultation>()
                for (consultationSnapshot in snapshot.children) {
                    val consultation = consultationSnapshot.getValue(Consultation::class.java)
                    consultation?.let { consultationList.add(it) }
                }
                _consultations.value = consultationList
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("ConsultationViewModel", "Error fetching consultations: ${error.message}")
            }
        })
    }

    // Mark consultation as answered
    fun answerConsultation(consultation: Consultation, responseText: String) {
        Log.d(
            "DrConsultationViewModel",
            "Processing consultation: ${consultation.question}, answer: $responseText"
        )

        // Reference to the global Consultations node
        val globalConsultationsRef = FirebaseDatabase.getInstance().getReference("Consultations")

        // Query the global Consultations node to find the matching clientId
        globalConsultationsRef.get().addOnSuccessListener { snapshot ->
            if (snapshot.exists()) {
                // Iterate through the keys in the global Consultations node
                for (childSnapshot in snapshot.children) {
                    val globalClientId = childSnapshot.key

                    if (globalClientId == consultation.clientId) {
                        Log.d("DrConsultationViewModel", "Found matching clientId: $globalClientId")

                        // Construct the path to the user's consultations
                        val userConsultationsRef = FirebaseDatabase.getInstance()
                            .getReference("users")
                            .child(globalClientId!!)
                            .child("requests")
                            .child("consultations")
                            .child(consultation.question)

                        Log.d("DrConsultationViewModel", "Attempting to update path: $userConsultationsRef")

                        // Ensure the consultation node exists
                        userConsultationsRef.get().addOnSuccessListener { userSnapshot ->
                            if (userSnapshot.exists()) {
                                Log.d("DrConsultationViewModel", "Question found in user's node: ${consultation.question}")

                                // Update the answer field
                                userConsultationsRef.child("answer").setValue(responseText)
                                    .addOnSuccessListener {
                                        Log.d(
                                            "DrConsultationViewModel",
                                            "Answer saved successfully in user's node for question: ${consultation.question}"
                                        )

                                        // Remove the consultation from the global Consultations node
                                        childSnapshot.ref.child(consultation.question).removeValue()
                                            .addOnSuccessListener {
                                                Log.d(
                                                    "DrConsultationViewModel",
                                                    "Consultation removed from global node"
                                                )
                                            }
                                            .addOnFailureListener { error ->
                                                Log.e(
                                                    "DrConsultationViewModel",
                                                    "Error removing consultation from global node: ${error.message}"
                                                )
                                            }
                                    }
                                    .addOnFailureListener { error ->
                                        Log.e(
                                            "DrConsultationViewModel",
                                            "Error saving answer in user's node: ${error.message}"
                                        )
                                    }
                            } else {
                                Log.e(
                                    "DrConsultationViewModel",
                                    "Consultation not found in user's node for question: ${consultation.question}"
                                )
                            }
                        }.addOnFailureListener { error ->
                            Log.e(
                                "DrConsultationViewModel",
                                "Error querying user's consultations: ${error.message}"
                            )
                        }

                        return@addOnSuccessListener // Exit loop after finding the match
                    }
                }

                Log.e(
                    "DrConsultationViewModel",
                    "No matching clientId found in global Consultations node for ${consultation.clientId}"
                )
            } else {
                Log.e("DrConsultationViewModel", "Global Consultations node is empty")
            }
        }.addOnFailureListener { error ->
            Log.e(
                "DrConsultationViewModel",
                "Error querying global Consultations node: ${error.message}"
            )
        }
    }

}
